package com.clipkeeper.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    fun setQuery(q: String) {
        _query.value = q
    }

    val clips: StateFlow<List<ClipEntity>> = combine(dao.observeAll(), _query) { list, q ->
        val s = q.trim().normalizeForSearch()
        if (s.isEmpty()) list
        else list.filter { ((it.name ?: "") + " " + (it.text ?: "")).normalizeForSearch().contains(s) }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Clipboard vừa lấy từ nút Ghim -> hiện popup đặt tên. */
    val pinRequest = MutableStateFlow<ClipEntity?>(null)
    val message = MutableStateFlow<String?>(null)

    fun clearMessage() {
        message.value = null
    }

    fun startPinFlow() {
        viewModelScope.launch {
            val r = ClipCapture.capture(getApplication())
            val id = ClipCapture.lastId
            val clip = if (id != null && (r == CaptureResult.SAVED || r == CaptureResult.DUPLICATE)) {
                dao.getById(id)
            } else null
            if (clip != null) {
                pinRequest.value = clip
            } else {
                message.value = if (r == CaptureResult.EMPTY) "Clipboard đang trống" else "Không đọc được clipboard"
            }
        }
    }

    fun confirmPin(c: ClipEntity, name: String) {
        viewModelScope.launch {
            dao.setNameAndPin(c.id, name.trim().ifEmpty { null })
            pinRequest.value = null
            message.value = "Đã ghim"
        }
    }

    fun cancelPin() {
        pinRequest.value = null
    }

    // ---- Khu vực bí mật ----
    val secretUnlocked = MutableStateFlow(false)

    val secretClips: StateFlow<List<ClipEntity>> = dao.observeSecret()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var failCount = 0
    private var lockUntil = 0L

    /** Trả về null nếu mở khóa thành công, ngược lại trả về thông báo lỗi. */
    fun tryUnlock(password: String): String? {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return "Thử lại sau ${(lockUntil - now) / 1000 + 1} giây"
        return if (SecretVault.check(getApplication(), password)) {
            failCount = 0
            secretUnlocked.value = true
            null
        } else {
            failCount++
            if (failCount >= 5) {
                lockUntil = now + 30_000
                failCount = 0
            }
            "Sai mật khẩu"
        }
    }

    fun lock() {
        secretUnlocked.value = false
    }

    fun moveToSecret(c: ClipEntity) {
        viewModelScope.launch { dao.setSecret(c.id, true) }
    }

    fun moveOutOfSecret(c: ClipEntity) {
        viewModelScope.launch { dao.setSecret(c.id, false) }
    }

    fun togglePin(c: ClipEntity) {
        viewModelScope.launch { dao.setPinned(c.id, !c.pinned) }
    }

    fun rename(c: ClipEntity, name: String) {
        viewModelScope.launch { dao.setName(c.id, name.trim().ifEmpty { null }) }
    }

    fun delete(c: ClipEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.delete(c)
            c.imagePath?.let { File(it).delete() }
        }
    }

    fun clearUnpinned() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.unpinnedImagePaths().forEach { File(it).delete() }
            dao.deleteUnpinned()
        }
    }

    fun addText(text: String) {
        viewModelScope.launch { ClipCapture.saveText(getApplication(), text) }
    }

    suspend fun captureNow(): CaptureResult = ClipCapture.capture(getApplication())
}
