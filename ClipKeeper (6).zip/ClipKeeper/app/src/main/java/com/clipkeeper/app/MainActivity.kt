package com.clipkeeper.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()
    private var pendingPin = false

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        pendingPin = intent?.action == ACTION_PIN
        intent?.action = null

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Prefs.serviceEnabled(this)) ClipboardService.start(this)

        setContent {
            ClipKeeperTheme {
                val unlocked by vm.secretUnlocked.collectAsState()
                if (unlocked) SecretScreen(vm) else MainScreen(vm)
            }
        }
    }

    // Rời khỏi app thì tự khóa khu vực bí mật.
    override fun onStop() {
        super.onStop()
        vm.lock()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == ACTION_PIN) {
            pendingPin = true
            intent.action = null
            // Nếu app đã có focus sẵn thì xử lý ngay, nếu chưa thì chờ onWindowFocusChanged.
            window.decorView.post { tryPin() }
        }
    }

    private fun tryPin(): Boolean {
        if (pendingPin && hasWindowFocus()) {
            pendingPin = false
            vm.startPinFlow()
            return true
        }
        return false
    }

    // Khi app đang hiển thị (có focus) thì đọc được clipboard.
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        if (pendingPin) {
            tryPin()
        } else {
            lifecycleScope.launch { ClipCapture.capture(applicationContext) }
        }
    }

    companion object {
        const val ACTION_PIN = "com.clipkeeper.app.PIN_CLIP"
    }
}
