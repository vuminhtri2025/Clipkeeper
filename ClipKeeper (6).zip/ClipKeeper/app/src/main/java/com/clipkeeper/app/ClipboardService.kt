package com.clipkeeper.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

object Prefs {
    private const val NAME = "clipkeeper"
    fun serviceEnabled(c: Context): Boolean =
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).getBoolean("service", false)

    fun setServiceEnabled(c: Context, v: Boolean) {
        c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean("service", v).apply()
    }
}

class ClipboardService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var cm: ClipboardManager
    private val listener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            cm.removePrimaryClipChangedListener(listener)
        } catch (_: Exception) {
        }
        scope.cancel()
        super.onDestroy()
    }

    private fun onClipChanged() {
        scope.launch {
            val result = ClipCapture.capture(this@ClipboardService)
            // Android 10+: ứng dụng nền không đọc được clipboard -> mở activity trong suốt để lấy focus và đọc.
            if (result == CaptureResult.DENIED && Settings.canDrawOverlays(this@ClipboardService)) {
                val i = Intent(this@ClipboardService, ClipReadActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                try {
                    startActivity(i)
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL_ID, "Theo dõi clipboard", NotificationManager.IMPORTANCE_MIN)
        nm.createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("ClipKeeper đang lưu clipboard")
            .setContentText("Nội dung bạn copy sẽ được lưu tự động")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "clip_monitor"
        private const val NOTIF_ID = 1001

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, ClipboardService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ClipboardService::class.java))
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.serviceEnabled(context)) {
            ClipboardService.start(context)
        }
    }
}
