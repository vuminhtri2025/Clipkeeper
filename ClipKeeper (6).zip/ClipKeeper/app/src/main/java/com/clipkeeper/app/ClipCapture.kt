package com.clipkeeper.app

import android.content.ClipboardManager
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

enum class CaptureResult { SAVED, DUPLICATE, EMPTY, DENIED }

object ClipCapture {

    @Volatile
    var lastId: Long? = null

    /** Hash của clipboard bí mật vừa được copy ra: không lưu lại vào danh sách chính. */
    @Volatile
    var ignoreHash: String? = null

    private const val MAX_TEXT = 200_000
    private const val MAX_HTML = 500_000

    suspend fun capture(context: Context): CaptureResult = withContext(Dispatchers.IO) {
        try {
            doCapture(context.applicationContext)
        } catch (e: Exception) {
            CaptureResult.DENIED
        }
    }

    suspend fun saveText(context: Context, text: String): CaptureResult = withContext(Dispatchers.IO) {
        saveTextClip(AppDatabase.get(context.applicationContext).dao(), text.take(MAX_TEXT), null)
    }

    private suspend fun doCapture(app: Context): CaptureResult {
        lastId = null
        val cm = app.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = try {
            cm.primaryClip
        } catch (e: Exception) {
            null
        }
        if (clip == null) {
            return if (cm.hasPrimaryClip()) CaptureResult.DENIED else CaptureResult.EMPTY
        }
        if (clip.itemCount == 0) return CaptureResult.EMPTY

        val item = clip.getItemAt(0)
        val dao = AppDatabase.get(app).dao()
        val now = System.currentTimeMillis()

        // ---- Hình ảnh ----
        val uri = item.uri
        if (uri != null) {
            val mime = try {
                app.contentResolver.getType(uri)
            } catch (e: Exception) {
                null
            }
            if (mime != null && mime.startsWith("image/")) {
                val ext = when (mime) {
                    "image/png" -> "png"
                    "image/gif" -> "gif"
                    "image/webp" -> "webp"
                    else -> "jpg"
                }
                val dir = File(app.filesDir, "images").apply { mkdirs() }
                val tmp = File(dir, "tmp_${System.nanoTime()}.$ext")
                try {
                    app.contentResolver.openInputStream(uri)?.use { input ->
                        tmp.outputStream().use { out -> input.copyTo(out) }
                    }
                } catch (e: Exception) {
                    tmp.delete()
                    return CaptureResult.DENIED
                }
                if (!tmp.exists() || tmp.length() == 0L) {
                    tmp.delete()
                    return CaptureResult.EMPTY
                }
                val hash = sha256(tmp.readBytes())
                if (shouldIgnore(hash)) {
                    tmp.delete()
                    return CaptureResult.DUPLICATE
                }
                val existing = dao.findByHash(hash)
                if (existing != null) {
                    tmp.delete()
                    dao.touch(existing.id, now)
                    lastId = existing.id
                    return CaptureResult.DUPLICATE
                }
                val finalFile = File(dir, "img_$now.$ext")
                if (!tmp.renameTo(finalFile)) {
                    tmp.copyTo(finalFile, overwrite = true)
                    tmp.delete()
                }
                lastId = dao.insert(
                    ClipEntity(
                        type = "IMAGE", text = null, html = null,
                        imagePath = finalFile.absolutePath, hash = hash, createdAt = now
                    )
                )
                return CaptureResult.SAVED
            }
        }

        // ---- Văn bản / định dạng / bảng ----
        val text = item.text?.toString()?.take(MAX_TEXT)
        val htmlRaw = item.htmlText
        val html = if (htmlRaw != null && htmlRaw.length <= MAX_HTML) htmlRaw else null
        if (text.isNullOrBlank() && html.isNullOrBlank()) return CaptureResult.EMPTY
        return saveTextClip(dao, text ?: "", html)
    }

    private suspend fun saveTextClip(dao: ClipDao, text: String, html: String?): CaptureResult {
        val now = System.currentTimeMillis()
        val type = when {
            html != null && html.contains("<table", ignoreCase = true) -> "TABLE"
            html != null -> "RICH"
            text.startsWith("http://") || text.startsWith("https://") ->
                if (text.any { it.isWhitespace() }) "TEXT" else "LINK"
            else -> "TEXT"
        }
        val hash = sha256(("$type|${html ?: ""}|$text").toByteArray())
        if (shouldIgnore(hash)) return CaptureResult.DUPLICATE
        val existing = dao.findByHash(hash)
        if (existing != null) {
            dao.touch(existing.id, now)
            lastId = existing.id
            return CaptureResult.DUPLICATE
        }
        lastId = dao.insert(
            ClipEntity(
                type = type, text = text, html = html,
                imagePath = null, hash = hash, createdAt = now
            )
        )
        return CaptureResult.SAVED
    }

    private fun shouldIgnore(hash: String): Boolean {
        val ig = ignoreHash ?: return false
        if (ig == hash) return true
        ignoreHash = null
        return false
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
}
