@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.clipkeeper.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val SecretBar = Color(0xFF37474F)

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun PasswordSetupDialog(title: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text("Không thể khôi phục nếu quên mật khẩu.", color = Gray, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = p1,
                    onValueChange = { p1 = it; err = null },
                    singleLine = true,
                    label = { Text("Mật khẩu (từ 4 ký tự)") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = p2,
                    onValueChange = { p2 = it; err = null },
                    singleLine = true,
                    label = { Text("Nhập lại mật khẩu") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    isError = err != null,
                    supportingText = { err?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    p1.length < 4 -> err = "Mật khẩu tối thiểu 4 ký tự"
                    p1 != p2 -> err = "Hai mật khẩu không khớp"
                    else -> onConfirm(p1)
                }
            }) { Text("Lưu") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun SecretScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val clips by vm.secretClips.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    var selected by remember { mutableStateOf<ClipEntity?>(null) }
    var detail by remember { mutableStateOf<ClipEntity?>(null) }
    var renaming by remember { mutableStateOf<ClipEntity?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var changePw by remember { mutableStateOf(false) }

    BackHandler { vm.lock() }

    // Chặn chụp màn hình / ẩn nội dung ở màn hình đa nhiệm khi đang ở khu vực bí mật.
    DisposableEffect(Unit) {
        val w = ctx.findActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    fun quickCopy(c: ClipEntity) {
        ClipActions.copy(ctx, c)
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        toast("Đã sao chép")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Khu vực khác", fontSize = 22.sp) },
                navigationIcon = {
                    IconButton(onClick = { vm.lock() }) {
                        Icon(Icons.Outlined.Close, contentDescription = "Khóa và thoát")
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Outlined.MoreVert, contentDescription = "Thêm")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Đổi mật khẩu") },
                                onClick = {
                                    menuOpen = false
                                    changePw = true
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SecretBar,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color.White
    ) { pad ->
        if (clips.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    "Chưa có clipboard nào.\nBấm vào một clipboard bên ngoài → \"Chuyển vào khu vực khác\".",
                    color = Gray,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(clips, key = { it.id }) { c ->
                    ClipRow(c, onClick = { selected = c }, onLongClick = { quickCopy(c) })
                }
            }
        }
    }

    selected?.let { clip ->
        ModalBottomSheet(onDismissRequest = { selected = null }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                ActionItem(Icons.Outlined.ContentCopy, "Sao chép") {
                    selected = null
                    quickCopy(clip)
                }
                ActionItem(
                    Icons.Outlined.Edit,
                    if (clip.name.isNullOrBlank()) "Đặt tên" else "Đổi tên"
                ) {
                    renaming = clip
                    selected = null
                }
                ActionItem(Icons.Outlined.Visibility, "Xem chi tiết") {
                    detail = clip
                    selected = null
                }
                ActionItem(Icons.Outlined.Share, "Chia sẻ") {
                    ClipActions.share(ctx, clip)
                    selected = null
                }
                ActionItem(Icons.Outlined.LockOpen, "Chuyển ra ngoài") {
                    vm.moveOutOfSecret(clip)
                    selected = null
                    toast("Đã chuyển ra danh sách chính")
                }
                ActionItem(Icons.Outlined.Delete, "Xóa") {
                    vm.delete(clip)
                    selected = null
                    toast("Đã xóa")
                }
            }
        }
    }

    detail?.let { clip ->
        AlertDialog(
            onDismissRequest = { detail = null },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Đóng") } },
            dismissButton = {
                TextButton(onClick = {
                    detail = null
                    quickCopy(clip)
                }) { Text("Sao chép") }
            },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                    val n = clip.name
                    if (!n.isNullOrBlank()) {
                        Text(n, color = Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                    }
                    ClipContent(clip, preview = false)
                }
            }
        )
    }

    renaming?.let { clip ->
        var nameText by remember(clip.id) { mutableStateOf(clip.name ?: "") }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Tên clipboard") },
            text = {
                OutlinedTextField(
                    value = nameText,
                    onValueChange = { nameText = it },
                    singleLine = true,
                    placeholder = { Text("Nhập tên để dễ tìm…") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.rename(clip, nameText)
                    renaming = null
                }) { Text("Lưu") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Hủy") } }
        )
    }

    if (changePw) {
        PasswordSetupDialog(
            title = "Đổi mật khẩu",
            onDismiss = { changePw = false },
            onConfirm = {
                SecretVault.setPassword(ctx, it)
                changePw = false
                toast("Đã đổi mật khẩu")
            }
        )
    }
}
