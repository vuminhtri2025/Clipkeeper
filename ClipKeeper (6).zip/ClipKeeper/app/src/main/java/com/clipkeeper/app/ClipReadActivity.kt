package com.clipkeeper.app

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/** Activity trong suốt: lấy focus trong tích tắc để đọc clipboard (Android 10+), rồi tự đóng. */
class ClipReadActivity : ComponentActivity() {
    private var done = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !done) {
            done = true
            val showToast = intent.getBooleanExtra(EXTRA_TOAST, false)
            lifecycleScope.launch {
                val result = ClipCapture.capture(applicationContext)
                if (showToast) {
                    val msg = when (result) {
                        CaptureResult.SAVED -> "Đã lưu clipboard"
                        CaptureResult.DUPLICATE -> "Clipboard này đã có, đã đưa lên đầu"
                        CaptureResult.EMPTY -> "Clipboard đang trống"
                        CaptureResult.DENIED -> "Không đọc được clipboard"
                    }
                    Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        }
    }

    companion object {
        const val EXTRA_TOAST = "toast"
    }
}
