# ClipKeeper - quy tắc R8 cho bản release
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Room (lớp *_Impl do KSP sinh ra được nạp bằng reflection)
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**
