package com.clipkeeper.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    fun setQuery(q: String) {
        _query.value = q
    }

    @OptIn(FlowPreview::class)
    val clips: StateFlow<List<ClipEntity>> = combine(
        dao.observeAll(),
        _query.debounce { if (it.isEmpty()) 0L else 150L } // gõ tìm kiếm mượt hơn
    ) { list, q ->
        val s = q.trim().normalizeForSearch()
        if (s.isEmpty()) list
        else list.filter { ((it.name ?: "") + " " + (it.text ?: "")).normalizeForSearch().contains(s) }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Clipboard vừa lấy từ nút Ghim -> hiện popup đặt tên. */
    val pinRequest = MutableStateFlow<ClipEntity?>(null)
    val message = MutableStateFlow<String?>(null)

    fun clearMessage() {
        message.value = null
    }

    fun startPinFlow() {
        viewModelScope.launch {
            val r = ClipCapture.capture(getApplication())
            val id = ClipCapture.lastId
            val clip = if (id != null && (r == CaptureResult.SAVED || r == CaptureResult.DUPLICATE)) {
                dao.getById(id)
            } else null
            if (clip != null) {
                pinRequest.value = clip
            } else {
                message.value = when (r) {
                    CaptureResult.EMPTY -> "Clipboard đang trống"
                    CaptureResult.DENIED -> "Không đọc được clipboard"
                    else -> "Không thể ghim clipboard này"
                }
            }
        }
    }

    fun confirmPin(c: ClipEntity, name: String) {
        viewModelScope.launch {
            dao.setNameAndPin(c.id, name.trim().ifEmpty { null })
            pinRequest.value = null
            message.value = "Đã ghim"
        }
    }

    fun cancelPin() {
        pinRequest.value = null
    }

    // ---- Khu vực bí mật ----
    val secretUnlocked = MutableStateFlow(false)

    val secretClips: StateFlow<List<ClipEntity>> = dao.observeSecret()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var failCount = 0
    private var lockUntil = 0L

    /** Trả về null nếu mở khóa thành công, ngược lại trả về thông báo lỗi. */
    fun tryUnlock(password: String): String? {
        val now = System.currentTimeMillis()
        if (now < lockUntil) return "Thử lại sau ${(lockUntil - now) / 1000 + 1} giây"
        return if (SecretVault.check(getApplication(), password)) {
            failCount = 0
            secretUnlocked.value = true
            null
        } else {
            failCount++
            if (failCount >= 5) {
                lockUntil = now + 30_000
                failCount = 0
            }
            "Sai mật khẩu"
        }
    }

    /** Quên mật khẩu: xóa toàn bộ clipboard bí mật và xóa mật khẩu (tạo mật khẩu mới ở lần chuyển tiếp theo). */
    fun resetSecret() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.secretImagePaths().forEach { File(it).delete() }
            dao.deleteSecret()
            SecretVault.clear(getApplication())
            failCount = 0
            lockUntil = 0L
            secretUnlocked.value = false
        }
    }

    fun backupTo(uri: Uri, password: String) {
        viewModelScope.launch {
            message.value = "Đang sao lưu…"
            message.value = try {
                val n = BackupManager.backup(getApplication(), uri, password)
                "Đã sao lưu $n clipboard"
            } catch (e: Exception) {
                "Sao lưu thất bại"
            }
        }
    }

    fun restoreFrom(uri: Uri, password: String) {
        viewModelScope.launch {
            message.value = "Đang khôi phục…"
            message.value = try {
                val n = BackupManager.restore(getApplication(), uri, password)
                "Đã khôi phục $n clipboard mới"
            } catch (e: BackupManager.BadBackupException) {
                "Sai mật khẩu hoặc file sao lưu không hợp lệ"
            } catch (e: Exception) {
                "Khôi phục thất bại"
            }
        }
    }

    fun lock() {
        secretUnlocked.value = false
    }

    fun moveToSecret(c: ClipEntity) {
        // Clipboard hệ thống vẫn đang chứa nội dung này -> không cho tự lưu lại vào danh sách chính.
        ClipCapture.setIgnoreHash(getApplication(), c.hash)
        viewModelScope.launch { dao.setSecret(c.id, true) }
    }

    fun moveOutOfSecret(c: ClipEntity) {
        viewModelScope.launch { dao.setSecret(c.id, false) }
    }

    fun togglePin(c: ClipEntity) {
        viewModelScope.launch { dao.setPinned(c.id, !c.pinned) }
    }

    fun rename(c: ClipEntity, name: String) {
        viewModelScope.launch { dao.setName(c.id, name.trim().ifEmpty { null }) }
    }

    fun delete(c: ClipEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.delete(c)
            c.imagePath?.let { File(it).delete() }
        }
    }

    fun clearUnpinned() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.unpinnedImagePaths().forEach { File(it).delete() }
            dao.deleteUnpinned()
        }
    }

    fun addText(text: String) {
        viewModelScope.launch { ClipCapture.saveText(getApplication(), text) }
    }

    suspend fun captureNow(): CaptureResult = ClipCapture.capture(getApplication())
}
