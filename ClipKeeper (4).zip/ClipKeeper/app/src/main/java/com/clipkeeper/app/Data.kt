package com.clipkeeper.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/** type: TEXT | LINK | RICH | TABLE | IMAGE */
@Entity(tableName = "clips", indices = [Index(value = ["hash"])])
data class ClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val text: String?,
    val html: String?,
    val imagePath: String?,
    val hash: String,
    val pinned: Boolean = false,
    val createdAt: Long,
    val name: String? = null
)

@Dao
interface ClipDao {
    @Query("SELECT * FROM clips ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ClipEntity>>

    @Insert
    suspend fun insert(c: ClipEntity): Long

    @Query("SELECT * FROM clips WHERE hash = :hash LIMIT 1")
    suspend fun findByHash(hash: String): ClipEntity?

    @Query("UPDATE clips SET createdAt = :t WHERE id = :id")
    suspend fun touch(id: Long, t: Long)

    @Query("UPDATE clips SET name = :name WHERE id = :id")
    suspend fun setName(id: Long, name: String?)

    @Query("UPDATE clips SET pinned = :p WHERE id = :id")
    suspend fun setPinned(id: Long, p: Boolean)

    @Delete
    suspend fun delete(c: ClipEntity)

    @Query("SELECT imagePath FROM clips WHERE pinned = 0 AND imagePath IS NOT NULL")
    suspend fun unpinnedImagePaths(): List<String>

    @Query("DELETE FROM clips WHERE pinned = 0")
    suspend fun deleteUnpinned()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE clips ADD COLUMN name TEXT")
    }
}

@Database(entities = [ClipEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ClipDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "clips.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
