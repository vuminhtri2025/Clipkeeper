package com.clipkeeper.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.get(app).dao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    fun setQuery(q: String) {
        _query.value = q
    }

    val clips: StateFlow<List<ClipEntity>> = combine(dao.observeAll(), _query) { list, q ->
        val s = q.trim().normalizeForSearch()
        if (s.isEmpty()) list
        else list.filter { ((it.name ?: "") + " " + (it.text ?: "")).normalizeForSearch().contains(s) }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun togglePin(c: ClipEntity) {
        viewModelScope.launch { dao.setPinned(c.id, !c.pinned) }
    }

    fun rename(c: ClipEntity, name: String) {
        viewModelScope.launch { dao.setName(c.id, name.trim().ifEmpty { null }) }
    }

    fun delete(c: ClipEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.delete(c)
            c.imagePath?.let { File(it).delete() }
        }
    }

    fun clearUnpinned() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.unpinnedImagePaths().forEach { File(it).delete() }
            dao.deleteUnpinned()
        }
    }

    fun addText(text: String) {
        viewModelScope.launch { ClipCapture.saveText(getApplication(), text) }
    }

    suspend fun captureNow(): CaptureResult = ClipCapture.capture(getApplication())
}
