@file:OptIn(ExperimentalFoundationApi::class)

package com.clipvault.app.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clipvault.app.Clip
import com.clipvault.app.ClipStore
import com.clipvault.app.ClipUtil
import com.clipvault.app.SECTION_PINNED
import com.clipvault.app.SECTION_SAVED
import com.clipvault.app.SECTION_SECRET
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class PreviewDialog { EDIT, TAG, ALBUM, DELETE }

/**
 * Xem clipboard dạng thẻ chữ (Text card).
 * Vuốt TRÁI: sang clipboard tiếp theo. Vuốt PHẢI: quay lại clipboard trước đó.
 */
@Composable
fun ClipPreview(state: PreviewState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val all by ClipStore.clips.collectAsState()
    val albums by ClipStore.albums.collectAsState()
    val items = remember(all, state) {
        val byId = all.associateBy { it.id }
        state.ids.mapNotNull { byId[it] }
    }
    var dialog by remember { mutableStateOf<PreviewDialog?>(null) }

    BackHandler(onBack = onClose)

    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val pager = rememberPagerState(initialPage = state.start.coerceIn(0, items.size - 1)) { items.size }
    val current: Clip = items.getOrNull(pager.currentPage) ?: items.last()
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy  HH:mm", Locale("vi", "VN")) }
    val title = remember(current.created) {
        dateFmt.format(Instant.ofEpochMilli(current.created).atZone(ZoneId.systemDefault()))
    }

    fun toast(msg: String) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            // Thanh trên: quay lại | ngày giờ | folder (album) | xóa
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại")
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        "${pager.currentPage + 1}/${items.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { dialog = PreviewDialog.ALBUM }) {
                    Icon(
                        Icons.Default.Folder,
                        "Album",
                        tint = if (current.albumId != null) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = { dialog = PreviewDialog.DELETE }) {
                    Icon(Icons.Default.Delete, "Xóa")
                }
            }

            HorizontalPager(
                state = pager,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 28.dp, vertical = 12.dp),
                pageSpacing = 12.dp,
                key = { items.getOrNull(it)?.id ?: it }
            ) { page ->
                val item = items.getOrNull(page)
                if (item != null) {
                    ClipCard(
                        item = item,
                        albumName = albums.firstOrNull { it.id == item.albumId }?.name,
                        active = page == pager.currentPage,
                        onCopy = {
                            if (item.isImage) {
                                ClipUtil.copyImage(ctx, item.imagePath ?: "")
                                toast("Đã sao chép ảnh")
                            } else {
                                ClipUtil.copy(ctx, item.text)
                                toast("Đã sao chép")
                            }
                        },
                        onEdit = { dialog = PreviewDialog.EDIT },
                        onTag = { dialog = PreviewDialog.TAG },
                        onPin = {
                            if (item.section == SECTION_PINNED) {
                                ClipStore.setSection(item.id, SECTION_SAVED)
                                toast("Đã bỏ ghim")
                            } else {
                                ClipStore.setSection(item.id, SECTION_PINNED)
                                toast("Đã ghim")
                            }
                        },
                        onSecret = {
                            if (item.section == SECTION_SECRET) {
                                ClipStore.setSection(item.id, SECTION_SAVED)
                                toast("Đã bỏ khỏi Album")
                            } else {
                                ClipStore.setSection(item.id, SECTION_SECRET)
                                toast("Đã chuyển sang Album")
                                onClose()
                            }
                        },
                        onShare = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                if (item.isImage) {
                                    type = "image/*"
                                    putExtra(Intent.EXTRA_STREAM, ClipUtil.imageUri(ctx, item.imagePath ?: ""))
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                } else {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, item.text)
                                }
                            }
                            ctx.startActivity(Intent.createChooser(send, "Chia sẻ").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        },
                        onDelete = { dialog = PreviewDialog.DELETE }
                    )
                }
            }

            // Gợi ý vuốt + chấm trang
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowLeft, null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "  Vuốt để duyệt  ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Icon(
                        Icons.AutoMirrored.Filled.KeyboardArrowRight, null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(Modifier.height(8.dp))
                Dots(pager.currentPage, items.size)
            }
        }
    }

    when (dialog) {
        PreviewDialog.EDIT -> TextInputDialog(
            title = "Chỉnh sửa clipboard",
            initial = current.text,
            hint = "Nội dung",
            multiline = true,
            onConfirm = {
                ClipStore.updateText(current.id, it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.TAG -> TextInputDialog(
            title = "Gắn tag",
            initial = current.tags.joinToString(", "),
            hint = "Các tag, cách nhau bằng dấu phẩy",
            onConfirm = { s ->
                ClipStore.setTags(current.id, s.split(",").map { it.trim().removePrefix("#") })
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.ALBUM -> AlbumPickDialog(
            albums = albums,
            current = current.albumId,
            onPick = {
                ClipStore.setAlbum(current.id, it)
                dialog = null
            },
            onCreate = {
                ClipStore.addAlbum(it, current.id)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.DELETE -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Xóa clipboard này?") },
            text = { Text("Hành động này không thể hoàn tác.") },
            confirmButton = {
                TextButton(onClick = {
                    ClipStore.delete(current.id)
                    dialog = null
                }) { Text("Xóa", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Hủy") } }
        )
        null -> {}
    }
}

@Composable
private fun ClipCard(
    item: Clip,
    albumName: String?,
    active: Boolean,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onTag: () -> Unit,
    onPin: () -> Unit,
    onSecret: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    var menu by remember { mutableStateOf(false) }

    // Chỉ thẻ đang ở giữa mới nhận thao tác (thẻ ló ra hai bên thì không).
    fun guard(f: () -> Unit): () -> Unit = { if (active) f() }

    val statusLabel = when (item.section) {
        SECTION_PINNED -> "Đã ghim"
        SECTION_SECRET -> "Bí mật"
        else -> "Đã lưu"
    }

    Column(
        Modifier
            .fillMaxSize()
            .clip(shape)
            .background(cs.surfaceVariant)
            .border(1.5.dp, if (active) cs.primary else cs.outline, shape)
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Pill(if (item.isImage) "ẢNH" else "TEXT", cs.primaryContainer, cs.primary)
            if (albumName != null) {
                Spacer(Modifier.width(8.dp))
                Pill(albumName, cs.secondaryContainer, cs.onSurface)
            }
            Spacer(Modifier.weight(1f))
            if (item.section == SECTION_PINNED) {
                Icon(Icons.Default.PushPin, null, Modifier.size(22.dp), tint = cs.primary)
            }
        }
        Spacer(Modifier.height(16.dp))

        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
          if (item.isImage) {
            ClipImage(
                path = item.imagePath ?: "",
                maxPx = 1600,
                scale = ContentScale.Fit,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
            )
          } else {
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                SelectionContainer {
                    Text(item.text, fontSize = 20.sp, lineHeight = 28.sp, color = cs.onSurface)
                }
            }
          }
            if (item.tags.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item.tags.forEach { t -> Pill("#$t", cs.secondaryContainer, cs.onSurface) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = cs.outline)
        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                timeAgo(item.created),
                color = cs.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            )
            Pill(statusLabel, Color(0xFF16351F), Color(0xFF4ADE80))
        }
        Spacer(Modifier.height(14.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = guard(onCopy),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.ContentCopy, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Sao chép", fontWeight = FontWeight.Bold)
            }
            if (!item.isImage) SquareButton(Icons.Default.Edit, "Sửa", guard(onEdit))
            SquareButton(Icons.Default.Tag, "Tag", guard(onTag))
            Box {
                SquareButton(Icons.Default.MoreHoriz, "Thêm", guard { menu = true })
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (item.section == SECTION_PINNED) "Bỏ ghim" else "Ghim") },
                        onClick = { menu = false; onPin() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (item.section == SECTION_SECRET) "Bỏ khỏi Album" else "Chuyển sang Album") },
                        onClick = { menu = false; onSecret() }
                    )
                    DropdownMenuItem(
                        text = { Text("Chia sẻ") },
                        onClick = { menu = false; onShare() }
                    )
                    DropdownMenuItem(
                        text = { Text("Xóa", color = cs.error) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun Pill(label: String, bg: Color, fg: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun SquareButton(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, Modifier.size(22.dp))
    }
}

@Composable
private fun Dots(page: Int, total: Int) {
    val n = minOf(total, 5)
    val active = when {
        total <= 5 -> page
        page < 2 -> page
        page > total - 3 -> n - (total - page)
        else -> 2
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until n) {
            Box(
                Modifier
                    .height(6.dp)
                    .width(if (i == active) 22.dp else 6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                        if (i == active) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outline
                    )
            )
        }
    }
}

private fun timeAgo(ms: Long): String {
    val minutes = (System.currentTimeMillis() - ms) / 60_000L
    return when {
        minutes < 1L -> "Vừa xong"
        minutes < 60L -> "$minutes phút trước"
        minutes < 1440L -> "${minutes / 60} giờ trước"
        minutes < 10080L -> "${minutes / 1440} ngày trước"
        else -> DateTimeFormatter.ofPattern("dd/MM/yyyy")
            .format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()))
    }
}
