package com.clipvault.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("clipvault", Context.MODE_PRIVATE)

    fun isBackground(c: Context): Boolean = sp(c).getBoolean("bg", false)

    fun setBackground(c: Context, value: Boolean) {
        sp(c).edit().putBoolean("bg", value).apply()
    }
}
