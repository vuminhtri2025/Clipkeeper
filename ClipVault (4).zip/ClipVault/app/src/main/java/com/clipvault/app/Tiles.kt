package com.clipvault.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

abstract class BaseTile(private val mode: String) : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        tile.state = Tile.STATE_INACTIVE
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, CaptureActivity::class.java).apply {
            putExtra(CaptureActivity.EXTRA_MODE, mode)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }

        fun launch() {
            if (Build.VERSION.SDK_INT >= 34) {
                val pi = PendingIntent.getActivity(
                    this, mode.hashCode(), intent,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                startActivityAndCollapse(pi)
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(intent)
            }
        }

        if (isLocked) {
            unlockAndRun { launch() }
        } else {
            launch()
        }
    }
}

/** Ô Quick Settings "Lưu clipboard". Nhấn giữ -> mở tab Đã lưu. */
class SaveTileService : BaseTile(CaptureActivity.MODE_SAVE)

/** Ô Quick Settings "Ghim clipboard". Nhấn giữ -> mở tab Đã ghim. */
class PinTileService : BaseTile(CaptureActivity.MODE_PIN)
