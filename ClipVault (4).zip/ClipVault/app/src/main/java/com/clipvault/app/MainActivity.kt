package com.clipvault.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.quicksettings.TileService
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.clipvault.app.ui.ClipApp
import com.clipvault.app.ui.ClipTheme

class MainActivity : FragmentActivity() {

    private var openTab by mutableIntStateOf(0)
    private var tabNonce by mutableIntStateOf(0)
    private var secretOpen by mutableStateOf(false)
    private var bgEnabled by mutableStateOf(false)

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(this)

        bgEnabled = Prefs.isBackground(this)
        if (bgEnabled) startBackground()
        handleIntent(intent)

        setContent {
            ClipTheme {
                ClipApp(
                    openTab = openTab,
                    tabNonce = tabNonce,
                    secretOpen = secretOpen,
                    onOpenSecret = { authenticate { secretOpen = true } },
                    onCloseSecret = { secretOpen = false },
                    bgEnabled = bgEnabled,
                    onBgChange = { toggleBackground(it) },
                    onOverlaySettings = { openOverlaySettings() },
                    onBatterySettings = { openBatterySettings() }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        // Rời app là khóa lại vùng bí mật.
        secretOpen = false
    }

    /** Nhấn giữ ô Quick Settings -> Android mở activity này với action QS_TILE_PREFERENCES. */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.action == TileService.ACTION_QS_TILE_PREFERENCES) {
            val cn: ComponentName? = if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_COMPONENT_NAME, ComponentName::class.java)
            } else {
                @Suppress("DEPRECATION")
                i.getParcelableExtra<ComponentName>(Intent.EXTRA_COMPONENT_NAME)
            }
            secretOpen = false
            openTab = if (cn?.className?.contains("Pin") == true) 1 else 0
            tabNonce += 1
        }
    }

    private fun authenticate(onSuccess: () -> Unit) {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BIOMETRIC_STRONG or DEVICE_CREDENTIAL
        } else {
            BIOMETRIC_STRONG
        }
        val canAuth = BiometricManager.from(this).canAuthenticate(authenticators)
        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(
                this,
                "Máy chưa cài đặt vân tay. Hãy thêm vân tay trong Cài đặt của điện thoại.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Vùng bí mật")
            .setSubtitle("Xác thực vân tay để tiếp tục")
            .setAllowedAuthenticators(authenticators)
            .apply { if (Build.VERSION.SDK_INT < 30) setNegativeButtonText("Hủy") }
            .build()
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
            }
        )
        prompt.authenticate(info)
    }

    private fun toggleBackground(on: Boolean) {
        bgEnabled = on
        Prefs.setBackground(this, on)
        if (on) {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            startBackground()
        } else {
            ClipService.stop(this)
        }
    }

    private fun startBackground() {
        try {
            ClipService.start(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun openOverlaySettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
