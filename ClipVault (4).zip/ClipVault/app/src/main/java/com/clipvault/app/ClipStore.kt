package com.clipvault.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.Executors

const val SECTION_SAVED = 0
const val SECTION_PINNED = 1
const val SECTION_SECRET = 2

data class Clip(
    val id: Long,
    val text: String,
    val created: Long,
    val section: Int,
    val tags: List<String>,
    val albumId: Long?
)

data class Album(val id: Long, val name: String, val created: Long)

internal class DbHelper(ctx: Context) : SQLiteOpenHelper(ctx, "clipvault.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE clips (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "text TEXT NOT NULL, " +
                "created INTEGER NOT NULL, " +
                "section INTEGER NOT NULL DEFAULT 0, " +
                "tags TEXT NOT NULL DEFAULT '', " +
                "album_id INTEGER)"
        )
        db.execSQL("CREATE INDEX idx_clips_section ON clips(section, created)")
        db.execSQL(
            "CREATE TABLE albums (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT NOT NULL, " +
                "created INTEGER NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Chưa có nâng cấp schema.
    }
}

/** Kho dữ liệu duy nhất của app (SQLite). Mọi thao tác ghi chạy trên 1 luồng nền rồi phát lại danh sách mới. */
object ClipStore {
    private const val MAX_LEN = 100_000
    private const val MAX_SAVED = 3000

    private lateinit var helper: DbHelper
    private var inited = false
    private val io = Executors.newSingleThreadExecutor()

    private val _clips = MutableStateFlow<List<Clip>>(emptyList())
    private val _albums = MutableStateFlow<List<Album>>(emptyList())
    val clips: StateFlow<List<Clip>> = _clips
    val albums: StateFlow<List<Album>> = _albums

    /** Khi app tự copy (nút Sao chép) thì bỏ qua sự kiện clipboard trong vài giây để khỏi lưu trùng. */
    @Volatile
    var suppressUntil: Long = 0L

    @Synchronized
    fun init(context: Context) {
        if (inited) return
        helper = DbHelper(context.applicationContext)
        inited = true
        io.execute { load() }
    }

    private fun load() {
        val db = helper.readableDatabase
        val list = ArrayList<Clip>()
        db.rawQuery(
            "SELECT id, text, created, section, tags, album_id FROM clips ORDER BY created DESC, id DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val tags = (c.getString(4) ?: "")
                    .split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                list.add(
                    Clip(
                        id = c.getLong(0),
                        text = c.getString(1) ?: "",
                        created = c.getLong(2),
                        section = c.getInt(3),
                        tags = tags,
                        albumId = if (c.isNull(5)) null else c.getLong(5)
                    )
                )
            }
        }
        val albums = ArrayList<Album>()
        db.rawQuery("SELECT id, name, created FROM albums ORDER BY created ASC", null).use { c ->
            while (c.moveToNext()) {
                albums.add(Album(c.getLong(0), c.getString(1) ?: "", c.getLong(2)))
            }
        }
        _clips.value = list
        _albums.value = albums
    }

    private fun write(block: (SQLiteDatabase) -> Unit) {
        io.execute {
            try {
                block(helper.writableDatabase)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            load()
        }
    }

    // ---------------------------------------------------------------- clips

    fun add(text: String, section: Int) {
        val t = text.take(MAX_LEN)
        if (t.isBlank()) return
        write { db ->
            if (section == SECTION_PINNED) {
                // Nếu đã có trong "Đã lưu" thì chỉ cần chuyển sang "Đã ghim".
                val moved = ContentValues()
                moved.put("section", SECTION_PINNED)
                val n = db.update("clips", moved, "text=? AND section=?", arrayOf(t, SECTION_SAVED.toString()))
                if (n > 0) return@write
                val exists = db.rawQuery(
                    "SELECT 1 FROM clips WHERE text=? AND section=? LIMIT 1",
                    arrayOf(t, SECTION_PINNED.toString())
                ).use { it.moveToFirst() }
                if (exists) return@write
            } else {
                val latest = db.rawQuery(
                    "SELECT text FROM clips WHERE section=? ORDER BY created DESC, id DESC LIMIT 1",
                    arrayOf(section.toString())
                ).use { if (it.moveToFirst()) it.getString(0) else null }
                if (latest == t) return@write
            }
            val v = ContentValues()
            v.put("text", t)
            v.put("created", System.currentTimeMillis())
            v.put("section", section)
            v.put("tags", "")
            db.insert("clips", null, v)
            if (section == SECTION_SAVED) {
                db.execSQL(
                    "DELETE FROM clips WHERE section=0 AND id NOT IN " +
                        "(SELECT id FROM clips WHERE section=0 ORDER BY created DESC LIMIT $MAX_SAVED)"
                )
            }
        }
    }

    fun updateText(id: Long, text: String) {
        val t = text.take(MAX_LEN)
        if (t.isBlank()) return
        write { db ->
            val v = ContentValues()
            v.put("text", t)
            db.update("clips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun setTags(id: Long, tags: List<String>) {
        val joined = tags.map { it.replace(",", " ").trim() }.filter { it.isNotEmpty() }.distinct().joinToString(",")
        write { db ->
            val v = ContentValues()
            v.put("tags", joined)
            db.update("clips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun setSection(id: Long, section: Int) {
        write { db ->
            val v = ContentValues()
            v.put("section", section)
            db.update("clips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun setAlbum(id: Long, albumId: Long?) {
        write { db ->
            val v = ContentValues()
            if (albumId == null) v.putNull("album_id") else v.put("album_id", albumId)
            db.update("clips", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun delete(id: Long) {
        write { db -> db.delete("clips", "id=?", arrayOf(id.toString())) }
    }

    // --------------------------------------------------------------- albums

    fun addAlbum(name: String, assignClipId: Long? = null) {
        val n = name.trim()
        if (n.isEmpty()) return
        write { db ->
            val v = ContentValues()
            v.put("name", n)
            v.put("created", System.currentTimeMillis())
            val albumId = db.insert("albums", null, v)
            if (assignClipId != null && albumId > 0) {
                val cv = ContentValues()
                cv.put("album_id", albumId)
                db.update("clips", cv, "id=?", arrayOf(assignClipId.toString()))
            }
        }
    }

    fun renameAlbum(id: Long, name: String) {
        val n = name.trim()
        if (n.isEmpty()) return
        write { db ->
            val v = ContentValues()
            v.put("name", n)
            db.update("albums", v, "id=?", arrayOf(id.toString()))
        }
    }

    fun deleteAlbum(id: Long) {
        write { db ->
            db.execSQL("UPDATE clips SET album_id=NULL WHERE album_id=?", arrayOf<Any>(id))
            db.delete("albums", "id=?", arrayOf(id.toString()))
        }
    }
}

/** Tiện ích đọc / ghi clipboard hệ thống. */
object ClipUtil {
    fun isSensitive(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.primaryClipDescription?.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
        } catch (e: Exception) {
            false
        }
    }

    /** Trả về null nếu clipboard trống, không phải chữ, hoặc app không được phép đọc (chạy nền trên Android 10+). */
    fun readText(ctx: Context): String? {
        return try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip
            if (clip == null || clip.itemCount == 0) {
                null
            } else {
                val s = clip.getItemAt(0).coerceToText(ctx)?.toString()
                if (s.isNullOrBlank()) null else s
            }
        } catch (e: Exception) {
            null
        }
    }

    fun copy(ctx: Context, text: String) {
        ClipStore.suppressUntil = System.currentTimeMillis() + 2500
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ClipVault", text))
    }
}
