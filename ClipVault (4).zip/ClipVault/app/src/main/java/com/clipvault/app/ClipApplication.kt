package com.clipvault.app

import android.app.Application

class ClipApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ClipStore.init(this)
    }
}
