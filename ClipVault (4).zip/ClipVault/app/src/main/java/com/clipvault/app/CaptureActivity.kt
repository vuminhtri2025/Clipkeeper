package com.clipvault.app

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

/**
 * Activity trong suốt. Android 10+ chỉ cho app đang có focus đọc clipboard,
 * nên Quick Settings tile / dịch vụ nền mở activity này, đợi có focus, đọc clipboard rồi đóng ngay.
 */
class CaptureActivity : Activity() {
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(this)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || done) return
        done = true

        val mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_SAVE
        val text = ClipUtil.readText(this)
        if (text == null) {
            if (mode != MODE_AUTO) toast("Clipboard trống")
        } else {
            when (mode) {
                MODE_PIN -> {
                    ClipStore.add(text, SECTION_PINNED)
                    toast("Đã ghim clipboard")
                }
                MODE_AUTO -> ClipStore.add(text, SECTION_SAVED)
                else -> {
                    ClipStore.add(text, SECTION_SAVED)
                    toast("Đã lưu clipboard")
                }
            }
        }
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)
    }

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_SAVE = "save"
        const val MODE_PIN = "pin"
        const val MODE_AUTO = "auto"
    }
}
