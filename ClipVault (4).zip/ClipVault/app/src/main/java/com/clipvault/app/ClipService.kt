package com.clipvault.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.content.ContextCompat

/**
 * Dịch vụ nền: lắng nghe clipboard và tự lưu vào tab "Đã lưu".
 *
 * Android 10+ không cho app nền đọc nội dung clipboard, nên khi đọc trực tiếp thất bại:
 *  1) nếu đã cấp quyền "Hiển thị trên ứng dụng khác": tạo 1 cửa sổ overlay 1x1px để lấy focus và đọc;
 *  2) nếu chưa: thử mở CaptureActivity trong suốt.
 */
class ClipService : Service() {
    private lateinit var cm: ClipboardManager
    private val handler = Handler(Looper.getMainLooper())
    private val listener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    override fun onCreate() {
        super.onCreate()
        ClipStore.init(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(listener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try {
            cm.removePrimaryClipChangedListener(listener)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Chạy nền ClipVault", NotificationManager.IMPORTANCE_MIN)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile_save)
            .setContentTitle("ClipVault đang ghi clipboard")
            .setContentText("Nhấn để mở ứng dụng")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun onClipChanged() {
        if (System.currentTimeMillis() < ClipStore.suppressUntil) return
        if (ClipUtil.isSensitive(this)) return // bỏ qua mật khẩu từ trình quản lý mật khẩu

        val text = ClipUtil.readText(this)
        if (text != null) {
            ClipStore.add(text, SECTION_SAVED)
            return
        }
        if (Settings.canDrawOverlays(this)) {
            readViaOverlay()
        } else {
            launchCapture()
        }
    }

    private fun launchCapture() {
        try {
            val i = Intent(this, CaptureActivity::class.java).apply {
                putExtra(CaptureActivity.EXTRA_MODE, CaptureActivity.MODE_AUTO)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(i)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun readViaOverlay() {
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val appCtx = this@ClipService
            var removed = false
            val view = object : View(appCtx) {
                override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
                    super.onWindowFocusChanged(hasWindowFocus)
                    if (hasWindowFocus && !removed) {
                        removed = true
                        val t = ClipUtil.readText(appCtx)
                        if (t != null) ClipStore.add(t, SECTION_SAVED)
                        try {
                            wm.removeView(this)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.START or Gravity.TOP
            wm.addView(view, lp)
            // Phòng khi không bao giờ có focus: tự gỡ sau 1,5 giây.
            handler.postDelayed({
                if (!removed) {
                    removed = true
                    try {
                        wm.removeView(view)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }, 1500)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val CHANNEL = "clip_bg"
        private const val NOTIF_ID = 1

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ClipService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ClipService::class.java))
        }
    }
}
