package com.clipvault.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.clipvault.app.Album

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    hint: String,
    multiline: Boolean = false,
    confirmText: String = "Lưu",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text(hint) },
                singleLine = !multiline,
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (multiline) Modifier.heightIn(min = 160.dp) else Modifier)
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value) }) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy") } }
    )
}

@Composable
fun AlbumManageDialog(
    album: Album,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    var value by remember { mutableStateOf(album.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Album") },
        text = {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it },
                    label = { Text("Tên album") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Xóa album không xóa clipboard bên trong, chúng chỉ được bỏ khỏi album.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = { TextButton(onClick = { onRename(value) }) { Text("Đổi tên") } },
        dismissButton = {
            Row {
                TextButton(onClick = onDelete) {
                    Text("Xóa album", color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = onDismiss) { Text("Hủy") }
            }
        }
    )
}

@Composable
fun AlbumPickDialog(
    albums: List<Album>,
    current: Long?,
    onPick: (Long?) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        TextInputDialog(
            title = "Album mới",
            initial = "",
            hint = "Tên album",
            confirmText = "Tạo",
            onConfirm = { onCreate(it) },
            onDismiss = { creating = false }
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Chuyển vào album") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                PickRow("Không thuộc album nào", current == null) { onPick(null) }
                albums.forEach { a -> PickRow(a.name, current == a.id) { onPick(a.id) } }
                PickRow("+ Tạo album mới", false) { creating = true }
            }
        },
        confirmButton = { },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}

@Composable
private fun PickRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selected) {
            Icon(Icons.Default.Check, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
        } else {
            Spacer(Modifier.width(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun SettingsDialog(
    bgEnabled: Boolean,
    onBgChange: (Boolean) -> Unit,
    onOverlay: () -> Unit,
    onBattery: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cài đặt") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Chạy nền ghi clipboard", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Tự động lưu mọi nội dung bạn copy vào tab Đã lưu.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = bgEnabled, onCheckedChange = onBgChange)
                }
                Text(
                    "Android 10 trở lên chặn app nền đọc clipboard. Để ghi nền ổn định hơn, hãy cấp " +
                        "quyền \"Hiển thị trên ứng dụng khác\" và tắt tối ưu pin cho ClipVault. " +
                        "Hai ô Quick Settings luôn hoạt động chính xác.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = onOverlay, modifier = Modifier.fillMaxWidth()) {
                    Text("Cấp quyền hiển thị trên ứng dụng khác")
                }
                OutlinedButton(onClick = onBattery, modifier = Modifier.fillMaxWidth()) {
                    Text("Tắt tối ưu pin")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng") } }
    )
}
