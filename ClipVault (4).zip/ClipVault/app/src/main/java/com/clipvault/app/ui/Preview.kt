@file:OptIn(ExperimentalFoundationApi::class)

package com.clipvault.app.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clipvault.app.Clip
import com.clipvault.app.ClipStore
import com.clipvault.app.ClipUtil
import com.clipvault.app.SECTION_PINNED
import com.clipvault.app.SECTION_SAVED
import com.clipvault.app.SECTION_SECRET
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private enum class PreviewDialog { EDIT, TAG, ALBUM, DELETE }

/** Xem clipboard toàn màn hình như xem ảnh: vuốt trái/phải để chuyển clipboard trước/sau. */
@Composable
fun ClipPreview(state: PreviewState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val all by ClipStore.clips.collectAsState()
    val albums by ClipStore.albums.collectAsState()
    val items = remember(all, state) {
        val byId = all.associateBy { it.id }
        state.ids.mapNotNull { byId[it] }
    }
    var dialog by remember { mutableStateOf<PreviewDialog?>(null) }

    BackHandler(onBack = onClose)

    if (items.isEmpty()) {
        LaunchedEffect(Unit) { onClose() }
        return
    }

    val pager = rememberPagerState(initialPage = state.start.coerceIn(0, items.size - 1)) { items.size }
    val current: Clip = items.getOrNull(pager.currentPage) ?: items.last()
    val dateFmt = remember { DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy  HH:mm", Locale("vi", "VN")) }
    val title = remember(current.created) {
        dateFmt.format(Instant.ofEpochMilli(current.created).atZone(ZoneId.systemDefault()))
    }
    val albumName = albums.firstOrNull { it.id == current.albumId }?.name
    val sectionName = when (current.section) {
        SECTION_PINNED -> "Đã ghim"
        SECTION_SECRET -> "Bí mật"
        else -> "Đã lưu"
    }

    fun toast(msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại")
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        "${pager.currentPage + 1}/${items.size} • $sectionName" +
                            (if (albumName != null) " • $albumName" else ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = {
                    if (current.section == SECTION_SECRET) {
                        ClipStore.setSection(current.id, SECTION_SAVED)
                        toast("Đã bỏ khỏi Bí mật")
                    } else {
                        ClipStore.setSection(current.id, SECTION_SECRET)
                        toast("Đã chuyển vào Bí mật")
                        onClose()
                    }
                }) {
                    Icon(
                        if (current.section == SECTION_SECRET) Icons.Default.LockOpen else Icons.Default.Lock,
                        "Bí mật"
                    )
                }
                IconButton(onClick = { dialog = PreviewDialog.DELETE }) {
                    Icon(Icons.Default.Delete, "Xóa")
                }
            }

            HorizontalPager(
                state = pager,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                key = { items.getOrNull(it)?.id ?: it }
            ) { page ->
                val item = items.getOrNull(page)
                if (item != null) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp)
                    ) {
                        SelectionContainer {
                            Text(item.text, fontSize = 18.sp, lineHeight = 26.sp)
                        }
                        if (item.tags.isNotEmpty()) {
                            Spacer(Modifier.height(16.dp))
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                item.tags.forEach { t ->
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(MaterialTheme.colorScheme.secondaryContainer)
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("#$t", style = MaterialTheme.typography.labelMedium)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider()
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                ActionButton(Icons.Default.ContentCopy, "Sao chép", Modifier.weight(1f)) {
                    ClipUtil.copy(ctx, current.text)
                    toast("Đã sao chép")
                }
                ActionButton(Icons.Default.Edit, "Sửa", Modifier.weight(1f)) {
                    dialog = PreviewDialog.EDIT
                }
                ActionButton(Icons.Default.Tag, "Tag", Modifier.weight(1f)) {
                    dialog = PreviewDialog.TAG
                }
                ActionButton(Icons.Default.Folder, "Album", Modifier.weight(1f)) {
                    dialog = PreviewDialog.ALBUM
                }
                ActionButton(
                    Icons.Default.PushPin,
                    if (current.section == SECTION_PINNED) "Bỏ ghim" else "Ghim",
                    Modifier.weight(1f)
                ) {
                    if (current.section == SECTION_PINNED) {
                        ClipStore.setSection(current.id, SECTION_SAVED)
                        toast("Đã bỏ ghim")
                    } else {
                        ClipStore.setSection(current.id, SECTION_PINNED)
                        toast("Đã ghim")
                    }
                }
            }
        }
    }

    when (dialog) {
        PreviewDialog.EDIT -> TextInputDialog(
            title = "Chỉnh sửa clipboard",
            initial = current.text,
            hint = "Nội dung",
            multiline = true,
            onConfirm = {
                ClipStore.updateText(current.id, it)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.TAG -> TextInputDialog(
            title = "Gắn tag",
            initial = current.tags.joinToString(", "),
            hint = "Các tag, cách nhau bằng dấu phẩy",
            onConfirm = { s ->
                ClipStore.setTags(current.id, s.split(",").map { it.trim().removePrefix("#") })
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.ALBUM -> AlbumPickDialog(
            albums = albums,
            current = current.albumId,
            onPick = {
                ClipStore.setAlbum(current.id, it)
                dialog = null
            },
            onCreate = {
                ClipStore.addAlbum(it, current.id)
                dialog = null
            },
            onDismiss = { dialog = null }
        )
        PreviewDialog.DELETE -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Xóa clipboard này?") },
            text = { Text("Hành động này không thể hoàn tác.") },
            confirmButton = {
                TextButton(onClick = {
                    ClipStore.delete(current.id)
                    dialog = null
                }) { Text("Xóa", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Hủy") } }
        )
        null -> {}
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label)
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, maxLines = 1)
    }
}
