# Compose, AndroidX và Biometric đã có sẵn consumer rules.
# Giữ lại thông tin dòng để dễ đọc stacktrace.
-keepattributes SourceFile,LineNumberTable
