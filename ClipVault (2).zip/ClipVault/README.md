# ClipVault

Ứng dụng lưu trữ clipboard cho Android (Kotlin + Jetpack Compose).

## Tính năng
- 2 tab chính: **Đã lưu** (tự động) và **Đã ghim**; nhấn giữ tab **Đã ghim** để vào tab **Bí mật** (xác thực vân tay).
- Ô Quick Settings **Lưu clipboard** và **Ghim clipboard**; nhấn giữ ô sẽ mở đúng tab trong app.
- Tùy chọn **chạy nền** ghi mọi clipboard được copy (⚙ Cài đặt).
- Giao diện lưới theo ngày như Google Photos, có ô tìm kiếm (hỗ trợ `#tag`).
- Xem Preview toàn màn hình, vuốt trái/phải để chuyển clipboard; sao chép nhanh, sửa, gắn tag, chuyển album.
- **Chọn nhiều**: nhấn giữ một ô để chọn, chạm thêm các ô khác; thanh dưới có Album / Ghim / Xóa. Giữ rồi kéo để thả cả nhóm vào album.
- **Album** nằm trên đầu tab Đã ghim (nhấn giữ album để đổi tên/xóa). Nhấn giữ một ô clipboard rồi kéo thả vào album để chuyển vào (thả vào "Tất cả" để bỏ khỏi album, thả vào "Album mới" để tạo album).
- **Chia sẻ vào ClipVault**: từ ứng dụng khác chọn Chia sẻ → ClipVault (chữ hoặc ảnh), rồi chọn Lưu clipboard hoặc Ghim clipboard.
- Nhấn giữ một tab rồi **kéo sang tab kia** để chuyển qua xem tab đó (nhấn giữ tab Đã ghim rồi thả ngay: vào tab Bí mật).

## Build trên GitHub
1. Đặt `ClipVault.zip` ở thư mục gốc repo và `.github/workflows/build.yml`.
2. Push lên nhánh `main` (hoặc chạy tay ở tab Actions → Build APK).
3. Tải APK ở mục **Releases** hoặc **Artifacts** của lần chạy.

Keystore: `app/signing/clipvault-release.jks` (alias `clipvault`, mật khẩu `clipvault123`) cũng được nhúng trong `build.yml`.
`versionCode` tự tăng theo số lần chạy workflow nên cài đè cập nhật được.
