package com.clipvault.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.clipvault.app.ui.ClipColorsTheme

/**
 * Nhận nội dung (chữ hoặc ảnh) khi người dùng chọn ClipVault trong bảng chia sẻ của Android,
 * rồi hỏi lưu vào "Đã lưu" hay "Đã ghim".
 */
class ShareActivity : ComponentActivity() {
    private val texts = ArrayList<String>()
    private val uris = ArrayList<Uri>()
    private var busy by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ClipStore.init(this)
        parse(intent)

        if (texts.isEmpty() && uris.isEmpty()) {
            Toast.makeText(this, "Không có nội dung để lưu", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val summary = when {
            uris.isNotEmpty() && texts.isNotEmpty() -> "${uris.size} ảnh và ${texts.size} đoạn chữ"
            uris.isNotEmpty() -> if (uris.size == 1) "1 ảnh" else "${uris.size} ảnh"
            texts.size == 1 -> texts[0]
            else -> "${texts.size} đoạn chữ"
        }

        setContent {
            ClipColorsTheme {
                AlertDialog(
                    onDismissRequest = { if (!busy) finish() },
                    title = { Text("Lưu vào ClipVault") },
                    text = {
                        Column {
                            Text(
                                summary,
                                maxLines = 4,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(Modifier.height(16.dp))
                            if (busy) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                                    Spacer(Modifier.width(12.dp))
                                    Text("Đang lưu...")
                                }
                            } else {
                                Button(
                                    onClick = { save(SECTION_SAVED) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                ) {
                                    Icon(Icons.Default.Save, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Lưu clipboard", fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = { save(SECTION_PINNED) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                ) {
                                    Icon(Icons.Default.PushPin, null, Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Ghim clipboard", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    },
                    confirmButton = {},
                    dismissButton = {
                        if (!busy) TextButton(onClick = { finish() }) { Text("Hủy") }
                    }
                )
            }
        }
    }

    private fun save(section: Int) {
        if (busy) return
        busy = true
        val appCtx = applicationContext
        val textList = ArrayList(texts)
        val uriList = ArrayList(uris)
        // Sao chép ảnh phải xong trước khi đóng activity (quyền đọc Uri gắn với activity này).
        Thread {
            var ok = 0
            var fail = 0
            textList.forEach {
                ClipStore.add(it, section)
                ok++
            }
            uriList.forEach {
                if (ClipStore.addImage(appCtx, it, section)) ok++ else fail++
            }
            runOnUiThread {
                val where = if (section == SECTION_PINNED) "Đã ghim" else "Đã lưu"
                val msg = when {
                    ok == 0 -> "Không lưu được nội dung"
                    fail > 0 -> "$where $ok mục, $fail ảnh lỗi"
                    ok == 1 -> "$where clipboard"
                    else -> "$where $ok mục"
                }
                Toast.makeText(appCtx, msg, Toast.LENGTH_SHORT).show()
                finish()
            }
        }.start()
    }

    private fun parse(i: Intent?) {
        if (i == null) return
        val type = i.type ?: ""
        when (i.action) {
            Intent.ACTION_SEND -> {
                val stream = streamExtra(i)
                if (stream != null && type.startsWith("image/")) {
                    uris.add(stream)
                } else {
                    i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                        ?.takeIf { it.isNotBlank() }
                        ?.let { texts.add(it) }
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                if (type.startsWith("image/")) {
                    uris.addAll(streamListExtra(i))
                } else {
                    i.getCharSequenceArrayListExtra(Intent.EXTRA_TEXT)
                        ?.map { it.toString() }
                        ?.filter { it.isNotBlank() }
                        ?.let { texts.addAll(it) }
                }
            }
        }
    }

    private fun streamExtra(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            i.getParcelableExtra(Intent.EXTRA_STREAM)
        }

    private fun streamListExtra(i: Intent): List<Uri> =
        if (Build.VERSION.SDK_INT >= 33) {
            i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList()
        } else {
            @Suppress("DEPRECATION")
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM) ?: emptyList()
        }
}
