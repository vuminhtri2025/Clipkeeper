@file:OptIn(ExperimentalFoundationApi::class)

package com.clipvault.app.ui

import android.app.Activity
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.clipvault.app.Album
import com.clipvault.app.Clip
import com.clipvault.app.ClipStore
import com.clipvault.app.SECTION_PINNED
import com.clipvault.app.SECTION_SAVED
import com.clipvault.app.SECTION_SECRET
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private val TAB_TITLES = listOf("Đã lưu", "Đã ghim")

/** Danh sách id clipboard đang xem trong Preview + vị trí bắt đầu. */
class PreviewState(val ids: List<Long>, val start: Int)

/** Tập clipboard đang được chọn (chế độ chọn nhiều). */
class Selection {
    var ids by mutableStateOf(setOf<Long>())
    val active: Boolean get() = ids.isNotEmpty()

    fun toggle(id: Long) {
        ids = if (id in ids) ids - id else ids + id
    }

    fun add(id: Long) {
        if (id !in ids) ids = ids + id
    }

    fun clear() {
        ids = emptySet()
    }
}

/** Khóa đặc biệt của các ô thả: "Tất cả" (bỏ khỏi album) và "Album mới". */
private const val DROP_ALL = -1L
private const val DROP_NEW = -2L

/** Trạng thái kéo một clipboard thả vào album. Toạ độ tính theo gốc cửa sổ. */
class AlbumDrag {
    var dragged by mutableStateOf<Clip?>(null)
    var count by mutableStateOf(1)
    var pos by mutableStateOf(Offset.Zero)
    var hover by mutableStateOf<Long?>(null)
    internal val rects = HashMap<Long, Rect>()
    internal var ids: List<Long> = emptyList()
    internal var onDrop: (List<Long>, Long) -> Unit = { _, _ -> }

    fun start(c: Clip, p: Offset, dragIds: List<Long>) {
        dragged = c
        ids = dragIds
        count = dragIds.size
        pos = p
        hover = hit(p)
    }

    fun move(d: Offset) {
        pos += d
        hover = hit(pos)
    }

    fun end() {
        val c = dragged
        val h = hover
        val list = ids
        dragged = null
        hover = null
        if (c != null && h != null) onDrop(list, h)
    }

    fun cancel() {
        dragged = null
        hover = null
    }

    private fun hit(p: Offset): Long? {
        for ((k, r) in rects) if (r.contains(p)) return k
        return null
    }
}

private fun matches(c: Clip, q: String): Boolean {
    if (q.isBlank()) return true
    val s = q.trim().removePrefix("#")
    return c.text.contains(s, ignoreCase = true) || c.tags.any { it.contains(s, ignoreCase = true) }
}

@Composable
fun ClipApp(
    openTab: Int,
    tabNonce: Int,
    secretOpen: Boolean,
    onOpenSecret: () -> Unit,
    onCloseSecret: () -> Unit,
    bgEnabled: Boolean,
    onBgChange: (Boolean) -> Unit,
    onOverlaySettings: () -> Unit,
    onBatterySettings: () -> Unit
) {
    val ctx = LocalContext.current
    val window = (ctx as? Activity)?.window
    val scope = rememberCoroutineScope()

    val allClips by ClipStore.clips.collectAsState()
    val albums by ClipStore.albums.collectAsState()

    var query by remember { mutableStateOf("") }
    var albumFilter by remember { mutableStateOf<Long?>(null) }
    var preview by remember { mutableStateOf<PreviewState?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var creatingAlbum by remember { mutableStateOf(false) }
    var managingAlbum by remember { mutableStateOf<Album?>(null) }
    var pendingIds by remember { mutableStateOf<List<Long>>(emptyList()) }
    var pickAlbum by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val sel = remember { Selection() }
    val drag = remember { AlbumDrag() }
    drag.onDrop = { ids, key ->
        when (key) {
            DROP_NEW -> {
                pendingIds = ids
                creatingAlbum = true
            }
            DROP_ALL -> {
                ClipStore.setAlbumMany(ids, null)
                Toast.makeText(ctx, "Đã bỏ ${ids.size} clipboard khỏi album", Toast.LENGTH_SHORT).show()
                sel.clear()
            }
            else -> {
                ClipStore.setAlbumMany(ids, key)
                val name = albums.firstOrNull { it.id == key }?.name ?: "album"
                val msg = if (ids.size == 1) "Đã chuyển vào \"$name\"" else "Đã chuyển ${ids.size} clipboard vào \"$name\""
                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                sel.clear()
            }
        }
    }

    val pagerState = rememberPagerState(initialPage = openTab.coerceIn(0, 1)) { 2 }

    // Mở từ Quick Settings (nhấn giữ ô) -> nhảy tới tab tương ứng.
    LaunchedEffect(tabNonce) {
        if (tabNonce > 0) pagerState.scrollToPage(openTab.coerceIn(0, 1))
    }

    // Album bị xóa thì bỏ bộ lọc.
    LaunchedEffect(albums) {
        val f = albumFilter
        if (f != null && albums.none { it.id == f }) albumFilter = null
    }

    // Vùng bí mật: chặn chụp màn hình / ảnh xem nhanh gần đây.
    DisposableEffect(secretOpen) {
        if (secretOpen) window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    BackHandler(enabled = secretOpen) { onCloseSecret() }
    LaunchedEffect(pagerState.currentPage, secretOpen) { sel.clear() }
    BackHandler(enabled = sel.active) { sel.clear() }

    val selClips = remember(allClips, sel.ids) { allClips.filter { it.id in sel.ids } }
    // Clipboard bị xóa ở nơi khác thì bỏ khỏi danh sách đã chọn.
    LaunchedEffect(allClips) {
        val alive = allClips.map { it.id }.toSet()
        val keep = sel.ids.filter { it in alive }.toSet()
        if (keep.size != sel.ids.size) sel.ids = keep
    }

    val saved = remember(allClips, query) {
        allClips.filter { it.section == SECTION_SAVED && matches(it, query) }
    }
    val pinned = remember(allClips, query, albumFilter) {
        allClips.filter {
            it.section == SECTION_PINNED &&
                (albumFilter == null || it.albumId == albumFilter) &&
                matches(it, query)
        }
    }
    val secret = remember(allClips, query) {
        allClips.filter { it.section == SECTION_SECRET && matches(it, query) }
    }
    val albumCounts = remember(allClips) {
        allClips.filter { it.section == SECTION_PINNED && it.albumId != null }
            .groupingBy { it.albumId }
            .eachCount()
    }

    val openPreview: (List<Clip>, Clip) -> Unit = { list, c ->
        preview = PreviewState(list.map { it.id }, list.indexOf(c).coerceAtLeast(0))
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(Modifier.fillMaxSize()) {
            if (secretOpen) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onCloseSecret) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại")
                    }
                    Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Bí mật", style = MaterialTheme.typography.titleLarge)
                }
            } else {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 4.dp, top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "ClipVault",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, "Cài đặt")
                    }
                }
            }

            SearchField(query) { query = it }

            if (!secretOpen) {
                TabBar(
                    selected = pagerState.currentPage,
                    onSelect = { i -> scope.launch { pagerState.animateScrollToPage(i) } },
                    onSecret = onOpenSecret
                )
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.weight(1f)
                ) { page ->
                    if (page == 0) {
                        ClipGrid(
                            clips = saved,
                            sel = sel,
                            onOpen = openPreview,
                            emptyText = "Chưa có clipboard nào.\nBật chạy nền hoặc dùng ô \"Lưu clipboard\" ở Quick Settings.",
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            AlbumBar(
                                albums = albums,
                                counts = albumCounts,
                                selected = albumFilter,
                                onSelect = { albumFilter = it },
                                onAdd = {
                                    pendingIds = emptyList()
                                    creatingAlbum = true
                                },
                                onManage = { managingAlbum = it },
                                drag = drag
                            )
                            ClipGrid(
                                clips = pinned,
                                drag = drag,
                                sel = sel,
                                onOpen = openPreview,
                                emptyText = "Chưa có clipboard nào được ghim.\nDùng ô \"Ghim clipboard\" ở Quick Settings hoặc ghim từ màn xem clipboard.\nNhấn giữ một ô rồi kéo vào album để sắp xếp.",
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            )
                        }
                    }
                }
            } else {
                ClipGrid(
                    clips = secret,
                    sel = sel,
                    onOpen = openPreview,
                    emptyText = "Vùng bí mật đang trống.\nMở một clipboard và nhấn biểu tượng khóa để chuyển vào đây.",
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }

        // Ô đang được kéo + gợi ý thả
        drag.dragged?.let { c ->
            val half = with(LocalDensity.current) { 48.dp.toPx() }
            Box(
                Modifier
                    .offset { IntOffset((drag.pos.x - half).roundToInt(), (drag.pos.y - half).roundToInt()) }
                    .size(96.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f))
                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
            ) {
                if (c.isImage) {
                    ClipImage(c.imagePath ?: "", 200, ContentScale.Crop, Modifier.fillMaxSize())
                } else {
                    Text(
                        c.text,
                        fontSize = 11.sp,
                        maxLines = 5,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
            if (drag.count > 1) {
                Text(
                    "${drag.count}",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .offset { IntOffset((drag.pos.x + half - 24f).roundToInt(), (drag.pos.y - half - 12f).roundToInt()) }
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
            Text(
                "Thả vào album ở trên",
                color = MaterialTheme.colorScheme.onPrimary,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 32.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        if (sel.active && drag.dragged == null) {
            val allPinned = selClips.isNotEmpty() && selClips.all { it.section == SECTION_PINNED }
            SelectionBar(
                count = sel.ids.size,
                showPin = !secretOpen,
                pinLabel = if (allPinned) "Bỏ ghim" else "Ghim",
                onAlbum = { pickAlbum = true },
                onPin = {
                    val ids = sel.ids.toList()
                    if (allPinned) ClipStore.setSectionMany(ids, SECTION_SAVED)
                    else ClipStore.setSectionMany(ids, SECTION_PINNED)
                    Toast.makeText(ctx, if (allPinned) "Đã bỏ ghim" else "Đã ghim", Toast.LENGTH_SHORT).show()
                    sel.clear()
                },
                onDelete = { confirmDelete = true },
                onClose = { sel.clear() },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        if (pickAlbum) {
            val ids = sel.ids.toList()
            AlbumPickDialog(
                albums = albums,
                current = -999L,
                onPick = { id ->
                    ClipStore.setAlbumMany(ids, id)
                    val name = albums.firstOrNull { it.id == id }?.name
                    Toast.makeText(
                        ctx,
                        if (name == null) "Đã bỏ khỏi album" else "Đã chuyển ${ids.size} clipboard vào \"$name\"",
                        Toast.LENGTH_SHORT
                    ).show()
                    pickAlbum = false
                    sel.clear()
                },
                onCreate = { name ->
                    ClipStore.addAlbumWith(name, ids)
                    pickAlbum = false
                    sel.clear()
                },
                onDismiss = { pickAlbum = false }
            )
        }

        if (confirmDelete) {
            val n = sel.ids.size
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("Xóa $n clipboard?") },
                text = { Text("Hành động này không thể hoàn tác.") },
                confirmButton = {
                    TextButton(onClick = {
                        ClipStore.deleteMany(sel.ids.toList())
                        confirmDelete = false
                        sel.clear()
                    }) { Text("Xóa", color = MaterialTheme.colorScheme.error) }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Hủy") } }
            )
        }

        preview?.let { st ->
            ClipPreview(state = st, onClose = { preview = null })
        }

        if (showSettings) {
            SettingsDialog(
                bgEnabled = bgEnabled,
                onBgChange = onBgChange,
                onOverlay = onOverlaySettings,
                onBattery = onBatterySettings,
                onDismiss = { showSettings = false }
            )
        }
        if (creatingAlbum) {
            TextInputDialog(
                title = "Album mới",
                initial = "",
                hint = "Tên album",
                confirmText = "Tạo",
                onConfirm = {
                    if (pendingIds.isEmpty()) {
                        ClipStore.addAlbum(it)
                    } else {
                        ClipStore.addAlbumWith(it, pendingIds)
                        sel.clear()
                    }
                    pendingIds = emptyList()
                    creatingAlbum = false
                },
                onDismiss = {
                    pendingIds = emptyList()
                    creatingAlbum = false
                }
            )
        }
        managingAlbum?.let { a ->
            AlbumManageDialog(
                album = a,
                onRename = {
                    ClipStore.renameAlbum(a.id, it)
                    managingAlbum = null
                },
                onDelete = {
                    ClipStore.deleteAlbum(a.id)
                    managingAlbum = null
                },
                onDismiss = { managingAlbum = null }
            )
        }
    }
}

@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        singleLine = true,
        placeholder = { Text("Tìm clipboard hoặc #tag") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQuery("") }) { Icon(Icons.Default.Close, "Xóa") }
            }
        },
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
    )
}

/**
 * Thanh 2 tab.
 * - Chạm: chuyển tab.
 * - Nhấn giữ rồi kéo sang tab kia (không thả): chuyển sang tab kia để xem.
 * - Nhấn giữ tab Đã ghim rồi thả ra mà không kéo: vào vùng bí mật (xác thực vân tay).
 */
@Composable
private fun TabBar(
    selected: Int,
    onSelect: (Int) -> Unit,
    onSecret: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val currentSelected by rememberUpdatedState(selected)
    Row(
        Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                var startTab = 0
                var moved = false
                detectDragGesturesAfterLongPress(
                    onDragStart = { p ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        startTab = if (p.x < size.width / 2f) 0 else 1
                        moved = false
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val t = if (change.position.x < size.width / 2f) 0 else 1
                        if (t != startTab) moved = true
                        if (moved && t != currentSelected) onSelect(t)
                    },
                    onDragEnd = {
                        if (!moved && startTab == 1) onSecret()
                    },
                    onDragCancel = { }
                )
            }
    ) {
        TAB_TITLES.forEachIndexed { i, title ->
            val active = selected == i
            Column(
                Modifier
                    .weight(1f)
                    .clickable { onSelect(i) }
                    .padding(top = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    title,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .height(3.dp)
                        .width(48.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (active) MaterialTheme.colorScheme.primary else Color.Transparent)
                )
            }
        }
    }
    HorizontalDivider()
}

@Composable
private fun AlbumBar(
    albums: List<Album>,
    counts: Map<Long?, Int>,
    selected: Long?,
    onSelect: (Long?) -> Unit,
    onAdd: () -> Unit,
    onManage: (Album) -> Unit,
    drag: AlbumDrag
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            AlbumChip("Tất cả", Icons.Default.Folder, selected == null, { onSelect(null) }, null, DROP_ALL, drag)
        }
        items(albums, key = { it.id }) { a ->
            AlbumChip(
                "${a.name} (${counts[a.id] ?: 0})",
                Icons.Default.Folder,
                selected == a.id,
                { onSelect(a.id) },
                { onManage(a) },
                a.id,
                drag
            )
        }
        item {
            AlbumChip("Album mới", Icons.Default.Add, false, onAdd, null, DROP_NEW, drag)
        }
    }
}

@Composable
private fun AlbumChip(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    onLong: (() -> Unit)?,
    dropKey: Long,
    drag: AlbumDrag
) {
    DisposableEffect(dropKey) { onDispose { drag.rects.remove(dropKey) } }
    val hovered = drag.dragged != null && drag.hover == dropKey
    val bg = when {
        hovered -> MaterialTheme.colorScheme.primary
        selected -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val fg = if (hovered) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier
            .onGloballyPositioned { drag.rects[dropKey] = it.boundsInRoot() }
            .clip(RoundedCornerShape(18.dp))
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = fg)
        Spacer(Modifier.width(6.dp))
        Text(label, maxLines = 1, style = MaterialTheme.typography.labelLarge, color = fg)
    }
}

// ------------------------------------------------------------------ lưới theo ngày

private sealed interface GridRow {
    val key: String
}

private data class HeaderRow(val title: String, val day: LocalDate) : GridRow {
    override val key: String = "h$day"
}

private data class CellRow(val clip: Clip) : GridRow {
    override val key: String = "c${clip.id}"
}

private fun groupByDay(clips: List<Clip>): List<GridRow> {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val fmt = DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy", Locale("vi", "VN"))
    val out = ArrayList<GridRow>()
    var last: LocalDate? = null
    for (c in clips) {
        val d = Instant.ofEpochMilli(c.created).atZone(zone).toLocalDate()
        if (d != last) {
            val title = when (d) {
                today -> "Hôm nay"
                today.minusDays(1) -> "Hôm qua"
                else -> fmt.format(d)
            }
            out.add(HeaderRow(title, d))
            last = d
        }
        out.add(CellRow(c))
    }
    return out
}

@Composable
private fun ClipGrid(
    clips: List<Clip>,
    onOpen: (List<Clip>, Clip) -> Unit,
    emptyText: String,
    modifier: Modifier = Modifier,
    drag: AlbumDrag? = null,
    sel: Selection
) {
    if (clips.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) {
            Text(
                emptyText,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(32.dp)
            )
        }
        return
    }
    val rows = remember(clips) { groupByDay(clips) }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = modifier,
        contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 4.dp, bottom = if (sel.active) 88.dp else 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(
            rows,
            key = { it.key },
            span = { if (it is HeaderRow) GridItemSpan(maxLineSpan) else GridItemSpan(1) }
        ) { row ->
            when (row) {
                is HeaderRow -> Text(
                    row.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 4.dp, top = 12.dp, bottom = 4.dp)
                )
                is CellRow -> ClipTile(row.clip, drag, sel) { onOpen(clips, row.clip) }
            }
        }
    }
}

@Composable
private fun ClipTile(item: Clip, drag: AlbumDrag?, sel: Selection, onClick: () -> Unit) {
    val isSelected = item.id in sel.ids
    var origin by remember { mutableStateOf(Offset.Zero) }
    val haptic = LocalHapticFeedback.current
    val timeFmt = remember { DateTimeFormatter.ofPattern("HH:mm") }
    val time = remember(item.created) {
        Instant.ofEpochMilli(item.created).atZone(ZoneId.systemDefault()).format(timeFmt)
    }

    Box(
        Modifier
            .aspectRatio(1f)
            .onGloballyPositioned { origin = it.positionInRoot() }
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { if (sel.active) sel.toggle(item.id) else onClick() }
            // Nhấn giữ: chọn ô này; giữ rồi kéo: kéo tất cả ô đã chọn vào album (tab Đã ghim).
            .pointerInput(item.id) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { local ->
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        sel.add(item.id)
                        drag?.start(item, origin + local, sel.ids.toList())
                    },
                    onDrag = { change, amount ->
                        change.consume()
                        drag?.move(amount)
                    },
                    onDragEnd = { drag?.end() },
                    onDragCancel = { drag?.cancel() }
                )
            }
    ) {
        if (item.isImage) {
            ClipImage(
                path = item.imagePath ?: "",
                maxPx = 400,
                scale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                item.text,
                fontSize = 12.sp,
                lineHeight = 15.sp,
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 22.dp)
            )
        }
        if (isSelected) {
            Box(
                Modifier
                    .matchParentSize()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f))
                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
            )
        }
        if (sel.active) {
            Icon(
                if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                null,
                Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .size(22.dp),
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
                .padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                time,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (item.tags.isNotEmpty()) {
                Icon(
                    Icons.Default.Tag,
                    null,
                    Modifier.size(12.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    showPin: Boolean,
    pinLabel: String,
    onAlbum: () -> Unit,
    onPin: () -> Unit,
    onDelete: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 6.dp
    ) {
        Row(Modifier.padding(vertical = 8.dp)) {
            BarButton(Icons.Default.Close, "Hủy ($count)", onClose)
            BarButton(Icons.Default.Folder, "Album", onAlbum)
            if (showPin) BarButton(Icons.Default.PushPin, pinLabel, onPin)
            BarButton(Icons.Default.Delete, "Xóa", onDelete)
        }
    }
}

@Composable
private fun RowScope.BarButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .weight(1f)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label)
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 11.sp, maxLines = 1)
    }
}
