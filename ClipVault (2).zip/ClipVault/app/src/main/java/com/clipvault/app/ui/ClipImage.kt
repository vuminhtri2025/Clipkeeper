package com.clipvault.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.clipvault.app.ImageLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ClipImage(path: String, maxPx: Int, scale: ContentScale, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(null, path, maxPx) {
        value = withContext(Dispatchers.IO) { ImageLoader.loadSync(path, maxPx)?.asImageBitmap() }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, contentScale = scale, modifier = modifier)
    } else {
        Box(modifier)
    }
}
