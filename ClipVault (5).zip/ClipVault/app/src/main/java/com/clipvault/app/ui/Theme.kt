package com.clipvault.app.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

val ClipOrange = Color(0xFFFF7A2F)

private val ClipColors = darkColorScheme(
    primary = ClipOrange,
    onPrimary = Color(0xFF1B0E04),
    primaryContainer = Color(0xFF3A2112),
    onPrimaryContainer = Color(0xFFFFC9A6),
    secondary = Color(0xFFB9B9C2),
    onSecondary = Color(0xFF111114),
    secondaryContainer = Color(0xFF2A2A31),
    onSecondaryContainer = Color(0xFFF2F2F5),
    background = Color(0xFF0B0B0F),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF141418),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF1E1E24),
    onSurfaceVariant = Color(0xFFB4B4BE),
    surfaceContainer = Color(0xFF1B1B21),
    surfaceContainerHigh = Color(0xFF23232A),
    surfaceContainerHighest = Color(0xFF2A2A32),
    outline = Color(0xFF3C3C46),
    outlineVariant = Color(0xFF2C2C34),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF1A0505)
)

/** Giao diện tối: nền đen, chữ trắng, điểm nhấn cam. */
@Composable
fun ClipTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = ClipColors) {
        // Surface đặt màu chữ mặc định = trắng cho mọi thành phần bên trong.
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.onBackground,
            content = content
        )
    }
}
