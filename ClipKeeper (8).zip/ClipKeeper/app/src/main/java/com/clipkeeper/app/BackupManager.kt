package com.clipkeeper.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.security.SecureRandom
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Sao lưu / khôi phục toàn bộ dữ liệu (kể cả khu vực bí mật và hình ảnh).
 * File sao lưu: "CKBK1" + salt(16) + iv(12) + AES-256-GCM(zip). Khóa sinh từ mật khẩu bằng PBKDF2-HMAC-SHA256.
 */
object BackupManager {

    class BadBackupException : Exception("Sai mật khẩu hoặc file sao lưu không hợp lệ")

    private const val MAGIC = "CKBK1"
    private const val ITERATIONS = 120_000

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    private fun random(n: Int) = ByteArray(n).also { SecureRandom().nextBytes(it) }

    private fun InputStream.readExactly(n: Int): ByteArray {
        val b = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = read(b, off, n - off)
            if (r < 0) throw BadBackupException()
            off += r
        }
        return b
    }

    private fun JSONObject.strOrNull(key: String): String? =
        if (isNull(key)) null else getString(key)

    /** Trả về số clipboard đã sao lưu. */
    suspend fun backup(context: Context, uri: Uri, password: String): Int = withContext(Dispatchers.IO) {
        val app = context.applicationContext
        val clips = AppDatabase.get(app).dao().getAll()
        val salt = random(16)
        val iv = random(12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password, salt), GCMParameterSpec(128, iv))

        val raw = app.contentResolver.openOutputStream(uri, "w") ?: throw IllegalStateException("Không ghi được file")
        val out = BufferedOutputStream(raw)
        out.write(MAGIC.toByteArray(Charsets.US_ASCII))
        out.write(salt)
        out.write(iv)
        val zip = ZipOutputStream(CipherOutputStream(out, cipher))
        try {
            val arr = JSONArray()
            for (c in clips) {
                val o = JSONObject()
                o.put("type", c.type)
                o.put("text", c.text ?: JSONObject.NULL)
                o.put("html", c.html ?: JSONObject.NULL)
                o.put("hash", c.hash)
                o.put("pinned", c.pinned)
                o.put("createdAt", c.createdAt)
                o.put("name", c.name ?: JSONObject.NULL)
                o.put("secret", c.secret)
                val p = c.imagePath
                if (p != null) {
                    val f = File(p)
                    if (f.exists()) {
                        val entry = "img_${c.id}_${f.name}"
                        zip.putNextEntry(ZipEntry(entry))
                        f.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        o.put("image", entry)
                    }
                }
                arr.put(o)
            }
            val root = JSONObject()
            root.put("version", 1)
            root.put("clips", arr)
            SecretVault.exportRaw(app)?.let { (s, h) ->
                root.put("vault", JSONObject().put("salt", s).put("hash", h))
            }
            zip.putNextEntry(ZipEntry("clips.json"))
            zip.write(root.toString().toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            zip.finish()
        } finally {
            zip.close() // ghi nốt khối cuối + thẻ xác thực GCM
        }
        clips.size
    }

    /** Khôi phục theo kiểu gộp (không xóa dữ liệu hiện có). Trả về số clipboard đã thêm. */
    suspend fun restore(context: Context, uri: Uri, password: String): Int = withContext(Dispatchers.IO) {
        val app = context.applicationContext
        val dao = AppDatabase.get(app).dao()
        val tmpDir = File(app.cacheDir, "restore_${System.nanoTime()}").apply { mkdirs() }
        try {
            try {
                val raw = app.contentResolver.openInputStream(uri) ?: throw BadBackupException()
                raw.use {
                    val inp = BufferedInputStream(it)
                    val magic = String(inp.readExactly(MAGIC.length), Charsets.US_ASCII)
                    if (magic != MAGIC) throw BadBackupException()
                    val salt = inp.readExactly(16)
                    val iv = inp.readExactly(12)
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt), GCMParameterSpec(128, iv))
                    val cin = CipherInputStream(inp, cipher)
                    val zip = ZipInputStream(cin)
                    var e = zip.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            val f = File(tmpDir, File(e.name).name) // chống zip-slip: chỉ lấy tên file
                            f.outputStream().use { o -> zip.copyTo(o) }
                        }
                        e = zip.nextEntry
                    }
                    // Đọc hết để GCM kiểm tra thẻ xác thực (sai mật khẩu sẽ báo lỗi ở đây).
                    val buf = ByteArray(8192)
                    while (cin.read(buf) != -1) { /* drain */ }
                }
            } catch (e: BadBackupException) {
                throw e
            } catch (e: Exception) {
                throw BadBackupException()
            }

            val json = File(tmpDir, "clips.json")
            if (!json.exists()) throw BadBackupException()
            val root = try {
                JSONObject(json.readText(Charsets.UTF_8))
            } catch (e: Exception) {
                throw BadBackupException()
            }

            val imagesDir = File(app.filesDir, "images").apply { mkdirs() }
            val arr = root.getJSONArray("clips")
            var added = 0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val hash = o.getString("hash")
                val secret = o.optBoolean("secret", false)
                if (dao.countHash(hash, secret) > 0) continue

                val type = o.getString("type")
                var imagePath: String? = null
                if (type == "IMAGE") {
                    val name = o.strOrNull("image") ?: continue
                    val src = File(tmpDir, File(name).name)
                    if (!src.exists()) continue
                    val dest = File(imagesDir, "r${System.nanoTime()}_${src.name}")
                    src.copyTo(dest, overwrite = true)
                    imagePath = dest.absolutePath
                }
                dao.insert(
                    ClipEntity(
                        type = type,
                        text = o.strOrNull("text"),
                        html = o.strOrNull("html"),
                        imagePath = imagePath,
                        hash = hash,
                        pinned = o.optBoolean("pinned", false),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                        name = o.strOrNull("name"),
                        secret = secret
                    )
                )
                added++
            }

            // Máy chưa có mật khẩu khu vực bí mật -> dùng mật khẩu trong bản sao lưu.
            val vault = root.optJSONObject("vault")
            if (vault != null && !SecretVault.hasPassword(app)) {
                SecretVault.importRaw(app, vault.getString("salt"), vault.getString("hash"))
            }
            added
        } finally {
            tmpDir.deleteRecursively()
        }
    }
}
