package com.clipkeeper.app

import android.content.Context
import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

/** type: TEXT | LINK | RICH | TABLE | IMAGE */
@Entity(tableName = "clips", indices = [Index(value = ["hash"])])
data class ClipEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val text: String?,
    val html: String?,
    val imagePath: String?,
    val hash: String,
    val pinned: Boolean = false,
    val createdAt: Long,
    val name: String? = null,
    @ColumnInfo(defaultValue = "0") val secret: Boolean = false
)

@Dao
interface ClipDao {
    @Query("SELECT * FROM clips WHERE secret = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ClipEntity>>

    @Query("SELECT * FROM clips")
    suspend fun getAll(): List<ClipEntity>

    @Query("SELECT COUNT(*) FROM clips WHERE hash = :hash AND secret = :secret")
    suspend fun countHash(hash: String, secret: Boolean): Int

    @Query("SELECT * FROM clips WHERE secret = 1 ORDER BY createdAt DESC")
    fun observeSecret(): Flow<List<ClipEntity>>

    @Query("SELECT imagePath FROM clips WHERE secret = 1 AND imagePath IS NOT NULL")
    suspend fun secretImagePaths(): List<String>

    @Query("DELETE FROM clips WHERE secret = 1")
    suspend fun deleteSecret()

    @Query("UPDATE clips SET secret = :s, pinned = 0 WHERE id = :id")
    suspend fun setSecret(id: Long, s: Boolean)

    @Insert
    suspend fun insert(c: ClipEntity): Long

    @Query("SELECT * FROM clips WHERE hash = :hash AND secret = 0 LIMIT 1")
    suspend fun findByHash(hash: String): ClipEntity?

    @Query("UPDATE clips SET createdAt = :t WHERE id = :id")
    suspend fun touch(id: Long, t: Long)

    @Query("SELECT * FROM clips WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ClipEntity?

    @Query("UPDATE clips SET name = :name, pinned = 1 WHERE id = :id")
    suspend fun setNameAndPin(id: Long, name: String?)

    @Query("UPDATE clips SET name = :name WHERE id = :id")
    suspend fun setName(id: Long, name: String?)

    @Query("UPDATE clips SET pinned = :p WHERE id = :id")
    suspend fun setPinned(id: Long, p: Boolean)

    @Delete
    suspend fun delete(c: ClipEntity)

    @Query("SELECT imagePath FROM clips WHERE pinned = 0 AND secret = 0 AND imagePath IS NOT NULL")
    suspend fun unpinnedImagePaths(): List<String>

    @Query("DELETE FROM clips WHERE pinned = 0 AND secret = 0")
    suspend fun deleteUnpinned()
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE clips ADD COLUMN name TEXT")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE clips ADD COLUMN secret INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [ClipEntity::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): ClipDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "clips.db"
                ).addMigrations(MIGRATION_1_2, MIGRATION_2_3).build().also { instance = it }
            }
    }
}
