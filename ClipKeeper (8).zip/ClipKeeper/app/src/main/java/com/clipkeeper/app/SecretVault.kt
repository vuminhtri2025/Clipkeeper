package com.clipkeeper.app

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Lưu mật khẩu khu vực bí mật dưới dạng băm PBKDF2 (không lưu mật khẩu gốc). */
object SecretVault {
    private const val PREFS = "clipkeeper_vault"
    private const val ITERATIONS = 60_000

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasPassword(c: Context): Boolean = prefs(c).contains("hash")

    fun setPassword(c: Context, password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(password, salt)
        prefs(c).edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun exportRaw(c: Context): Pair<String, String>? {
        val p = prefs(c)
        val s = p.getString("salt", null) ?: return null
        val h = p.getString("hash", null) ?: return null
        return s to h
    }

    fun importRaw(c: Context, salt: String, hash: String) {
        prefs(c).edit().putString("salt", salt).putString("hash", hash).apply()
    }

    fun clear(c: Context) {
        prefs(c).edit().clear().apply()
    }

    fun check(c: Context, password: String): Boolean {
        val p = prefs(c)
        val salt = p.getString("salt", null) ?: return false
        val stored = p.getString("hash", null) ?: return false
        val h = derive(password, Base64.decode(salt, Base64.NO_WRAP))
        return MessageDigest.isEqual(h, Base64.decode(stored, Base64.NO_WRAP))
    }

    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
}
