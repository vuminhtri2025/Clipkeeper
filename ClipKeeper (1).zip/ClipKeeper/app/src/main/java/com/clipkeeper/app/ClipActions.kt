package com.clipkeeper.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.Normalizer

object ClipActions {

    private fun imageUri(context: Context, clip: ClipEntity) =
        FileProvider.getUriForFile(
            context, "${context.packageName}.fileprovider", File(clip.imagePath!!)
        )

    fun copy(context: Context, clip: ClipEntity) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val data = when {
            clip.type == "IMAGE" && clip.imagePath != null ->
                ClipData.newUri(context.contentResolver, "image", imageUri(context, clip))
            clip.html != null ->
                ClipData.newHtmlText("clip", clip.text ?: "", clip.html)
            else -> ClipData.newPlainText("clip", clip.text ?: "")
        }
        cm.setPrimaryClip(data)
    }

    fun share(context: Context, clip: ClipEntity) {
        val send = Intent(Intent.ACTION_SEND)
        if (clip.type == "IMAGE" && clip.imagePath != null) {
            send.type = "image/*"
            send.putExtra(Intent.EXTRA_STREAM, imageUri(context, clip))
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } else {
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_TEXT, clip.text ?: "")
        }
        val chooser = Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}

/** Bỏ dấu tiếng Việt + chữ thường để tìm kiếm không phân biệt dấu. */
fun String.normalizeForSearch(): String =
    Normalizer.normalize(this.lowercase(), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace('đ', 'd')
