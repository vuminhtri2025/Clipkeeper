@file:OptIn(ExperimentalMaterial3Api::class)

package com.clipkeeper.app

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FormatColorText
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.TableChart
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

val Blue = Color(0xFF2D82CB)
val Gray = Color(0xFF757575)
val LineGray = Color(0xFFE0E0E0)

@Composable
fun ClipKeeperTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            onPrimary = Color.White,
            background = Color.White,
            surface = Color.White
        ),
        content = content
    )
}

sealed interface ListRow {
    data class Header(val title: String) : ListRow
    data class Item(val clip: ClipEntity) : ListRow
}

private val dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy")

private fun dateLabel(ts: Long): String {
    val d = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate()
    val today = LocalDate.now()
    return when (d) {
        today -> "Hôm nay"
        today.minusDays(1) -> "Hôm qua"
        else -> d.format(dateFormat)
    }
}

private fun buildRows(clips: List<ClipEntity>, tab: Int): List<ListRow> {
    val rows = mutableListOf<ListRow>()
    val pinned = clips.filter { it.pinned }
    if (tab == 1) {
        if (pinned.isNotEmpty()) {
            rows += ListRow.Header("Đã ghim")
            pinned.forEach { rows += ListRow.Item(it) }
        }
        return rows
    }
    if (pinned.isNotEmpty()) {
        rows += ListRow.Header("Đã ghim")
        pinned.forEach { rows += ListRow.Item(it) }
    }
    var last: String? = null
    clips.filter { !it.pinned }.forEach { c ->
        val label = dateLabel(c.createdAt)
        if (label != last) {
            rows += ListRow.Header(label)
            last = label
        }
        rows += ListRow.Item(c)
    }
    return rows
}

@Composable
fun MainScreen(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val clips by vm.clips.collectAsState()
    val query by vm.query.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<ClipEntity?>(null) }
    var detail by remember { mutableStateOf<ClipEntity?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var serviceOn by remember { mutableStateOf(Prefs.serviceEnabled(ctx)) }

    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun toast(msg: String) {
        scope.launch { snackbar.showSnackbar(msg) }
    }

    val rows = remember(clips, tab) { buildRows(clips, tab) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (searching) {
                            val focus = remember { FocusRequester() }
                            TextField(
                                value = query,
                                onValueChange = { vm.setQuery(it) },
                                singleLine = true,
                                placeholder = { Text("Gõ để tìm kiếm…", color = Color.White.copy(alpha = 0.7f)) },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = Color.White,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth().focusRequester(focus)
                            )
                            LaunchedEffect(Unit) { focus.requestFocus() }
                        } else {
                            Text("Clipper", fontSize = 24.sp)
                        }
                    },
                    navigationIcon = {
                        if (searching) {
                            IconButton(onClick = {
                                searching = false
                                vm.setQuery("")
                            }) { Icon(Icons.Outlined.Close, contentDescription = "Đóng tìm kiếm") }
                        }
                    },
                    actions = {
                        if (!searching) {
                            IconButton(onClick = { searching = true }) {
                                Icon(Icons.Outlined.Search, contentDescription = "Tìm kiếm")
                            }
                            IconButton(onClick = { confirmClear = true }) {
                                Icon(Icons.Outlined.DeleteSweep, contentDescription = "Xóa clipboard chưa ghim")
                            }
                            Box {
                                IconButton(onClick = { menuOpen = true }) {
                                    Icon(Icons.Outlined.MoreVert, contentDescription = "Thêm")
                                }
                                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(if (serviceOn) "Tắt lưu tự động nền" else "Bật lưu tự động nền")
                                        },
                                        onClick = {
                                            menuOpen = false
                                            serviceOn = !serviceOn
                                            Prefs.setServiceEnabled(ctx, serviceOn)
                                            if (serviceOn) ClipboardService.start(ctx) else ClipboardService.stop(ctx)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Cấp quyền hiển thị trên ứng dụng khác") },
                                        onClick = {
                                            menuOpen = false
                                            ctx.startActivity(
                                                Intent(
                                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse("package:${ctx.packageName}")
                                                )
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Blue,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White,
                        actionIconContentColor = Color.White
                    )
                )
                TabRow(
                    selectedTabIndex = tab,
                    containerColor = Blue,
                    contentColor = Color.White,
                    indicator = { positions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(positions[tab]),
                            color = Color.White
                        )
                    }
                ) {
                    Tab(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        text = { Text("CLIPBOARD", fontWeight = FontWeight.Medium) },
                        unselectedContentColor = Color.White.copy(alpha = 0.7f)
                    )
                    Tab(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        text = { Text("ĐÃ GHIM", fontWeight = FontWeight.Medium) },
                        unselectedContentColor = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAdd = true },
                containerColor = Blue,
                contentColor = Color.White,
                shape = CircleShape
            ) { Icon(Icons.Outlined.Add, contentDescription = "Thêm") }
        },
        containerColor = Color.White
    ) { pad ->
        if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    text = when {
                        query.isNotBlank() -> "Không tìm thấy kết quả"
                        tab == 1 -> "Chưa có clipboard nào được ghim"
                        else -> "Chưa có clipboard nào.\nHãy copy nội dung bất kỳ."
                    },
                    color = Gray,
                    modifier = Modifier.padding(32.dp)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                items(
                    rows,
                    key = { r ->
                        when (r) {
                            is ListRow.Header -> "h_${r.title}"
                            is ListRow.Item -> "i_${r.clip.id}"
                        }
                    }
                ) { r ->
                    when (r) {
                        is ListRow.Header -> SectionHeader(r.title)
                        is ListRow.Item -> ClipRow(r.clip) { selected = r.clip }
                    }
                }
            }
        }
    }

    // ---- Bottom sheet: tùy chọn khi bấm vào clipboard ----
    selected?.let { clip ->
        ModalBottomSheet(onDismissRequest = { selected = null }) {
            Column(Modifier.padding(bottom = 24.dp)) {
                ActionItem(Icons.Outlined.ContentCopy, "Sao chép") {
                    ClipActions.copy(ctx, clip)
                    selected = null
                    toast("Đã sao chép")
                }
                ActionItem(
                    Icons.Outlined.PushPin,
                    if (clip.pinned) "Bỏ ghim" else "Ghim"
                ) {
                    vm.togglePin(clip)
                    selected = null
                }
                ActionItem(Icons.Outlined.Visibility, "Xem chi tiết") {
                    detail = clip
                    selected = null
                }
                ActionItem(Icons.Outlined.Share, "Chia sẻ") {
                    ClipActions.share(ctx, clip)
                    selected = null
                }
                ActionItem(Icons.Outlined.Delete, "Xóa") {
                    vm.delete(clip)
                    selected = null
                    toast("Đã xóa")
                }
            }
        }
    }

    // ---- Xem chi tiết ----
    detail?.let { clip ->
        AlertDialog(
            onDismissRequest = { detail = null },
            confirmButton = { TextButton(onClick = { detail = null }) { Text("Đóng") } },
            dismissButton = {
                TextButton(onClick = {
                    ClipActions.copy(ctx, clip)
                    detail = null
                    toast("Đã sao chép")
                }) { Text("Sao chép") }
            },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                    ClipContent(clip, preview = false)
                }
            }
        )
    }

    // ---- Thêm clipboard ----
    if (showAdd) {
        var txt by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Thêm clipboard") },
            text = {
                OutlinedTextField(
                    value = txt,
                    onValueChange = { txt = it },
                    placeholder = { Text("Nhập nội dung…") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (txt.isNotBlank()) vm.addText(txt)
                    showAdd = false
                }) { Text("Lưu") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAdd = false
                    scope.launch {
                        val r = vm.captureNow()
                        snackbar.showSnackbar(
                            when (r) {
                                CaptureResult.SAVED -> "Đã lưu clipboard hiện tại"
                                CaptureResult.DUPLICATE -> "Clipboard này đã có trong danh sách"
                                CaptureResult.EMPTY -> "Clipboard đang trống"
                                CaptureResult.DENIED -> "Không đọc được clipboard"
                            }
                        )
                    }
                }) { Text("Dán từ clipboard") }
            }
        )
    }

    // ---- Xác nhận xóa ----
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Xóa clipboard?") },
            text = { Text("Xóa toàn bộ clipboard chưa ghim. Các mục đã ghim sẽ được giữ lại.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearUnpinned()
                    confirmClear = false
                    toast("Đã xóa")
                }) { Text("Xóa") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Hủy") } }
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    Column {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFFF5F5F5)).padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(title, color = Gray, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
        HorizontalDivider(color = LineGray)
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        leadingContent = { Icon(icon, contentDescription = null, tint = Blue) },
        modifier = Modifier.clickable(onClick = onClick)
    )
}

private fun typeIcon(type: String): ImageVector = when (type) {
    "IMAGE" -> Icons.Outlined.Image
    "TABLE" -> Icons.Outlined.TableChart
    "LINK" -> Icons.Outlined.Link
    "RICH" -> Icons.Outlined.FormatColorText
    else -> Icons.Outlined.ContentPaste
}

@Composable
private fun ClipRow(clip: ClipEntity, onClick: () -> Unit) {
    val time = remember(clip.createdAt) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(clip.createdAt))
    }
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(time, color = Gray, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Icon(typeIcon(clip.type), contentDescription = null, tint = Gray, modifier = Modifier.size(16.dp))
                if (clip.pinned) {
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Outlined.PushPin, contentDescription = "Đã ghim", tint = Blue, modifier = Modifier.size(16.dp))
                }
            }
            Spacer(Modifier.height(6.dp))
            ClipContent(clip, preview = true)
        }
        HorizontalDivider(color = LineGray)
    }
}

@Composable
private fun ClipContent(clip: ClipEntity, preview: Boolean) {
    when (clip.type) {
        "IMAGE" -> {
            AsyncImage(
                model = clip.imagePath?.let { File(it) },
                contentDescription = "Hình ảnh",
                contentScale = ContentScale.Fit,
                alignment = Alignment.CenterStart,
                modifier = if (preview) Modifier.fillMaxWidth().heightIn(max = 160.dp)
                else Modifier.fillMaxWidth()
            )
        }
        "TABLE" -> {
            val table = remember(clip.id) { parseTable(clip.html ?: "") }
            if (table.isEmpty()) {
                PlainText(clip.text ?: "", preview)
            } else {
                TableView(table, if (preview) 4 else Int.MAX_VALUE)
            }
        }
        "RICH" -> {
            if (preview) {
                PlainText(clip.text ?: "", true)
            } else {
                AndroidView(
                    factory = { c ->
                        TextView(c).apply {
                            text = HtmlCompat.fromHtml(clip.html ?: "", HtmlCompat.FROM_HTML_MODE_COMPACT)
                            textSize = 16f
                            setTextIsSelectable(true)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        else -> PlainText(clip.text ?: "", preview)
    }
}

@Composable
private fun PlainText(text: String, preview: Boolean) {
    if (preview) {
        Text(text, fontSize = 18.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
    } else {
        SelectionContainer { Text(text, fontSize = 16.sp) }
    }
}

@Composable
private fun TableView(rows: List<List<String>>, maxRows: Int) {
    val cols = rows.maxOfOrNull { it.size } ?: 0
    val border = Color(0xFFBDBDBD)
    Column(Modifier.horizontalScroll(rememberScrollState()).border(1.dp, border)) {
        rows.take(maxRows).forEach { r ->
            Row(Modifier.height(IntrinsicSize.Min)) {
                for (i in 0 until cols) {
                    Box(
                        Modifier.widthIn(min = 64.dp, max = 180.dp)
                            .fillMaxHeight()
                            .border(0.5.dp, border)
                            .padding(6.dp)
                    ) {
                        Text(
                            r.getOrElse(i) { "" },
                            fontSize = 14.sp,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

private val rowRegex = Regex("<tr[^>]*>(.*?)</tr>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
private val cellRegex = Regex("<t[dh][^>]*>(.*?)</t[dh]>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

private fun parseTable(html: String): List<List<String>> =
    rowRegex.findAll(html).map { r ->
        cellRegex.findAll(r.groupValues[1]).map {
            HtmlCompat.fromHtml(it.groupValues[1], HtmlCompat.FROM_HTML_MODE_COMPACT).toString().trim()
        }.toList()
    }.filter { it.isNotEmpty() }.toList()
